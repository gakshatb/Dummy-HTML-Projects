---
title: 'DHCP in One Picture'
description: 'Here is what happens when a new device joins the network.'
author:
  name: 'Kamran Ahmed'
  url: 'https://twitter.com/kamrify'
  imageUrl: '/authors/kamranahmedse.jpeg'
seo:
  title: 'DHCP in One Picture - roadmap.sh'
  description: 'Here is what happens when a new device joins the network.'
isNew: false
type: 'visual'
date: 2021-04-28
sitemap:
  priority: 0.7
  changefreq: 'weekly'
tags:
  - 'guide'
  - 'visual-guide'
  - 'guide-sitemap'
---

[![DHCP in One Picture](/guides/dhcp.png)](/guides/dhcp.png)
