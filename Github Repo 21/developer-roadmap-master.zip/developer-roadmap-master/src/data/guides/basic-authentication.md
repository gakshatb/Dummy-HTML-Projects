---
title: 'Basic Authentication'
description: 'Understand what is basic authentication and how it is implemented'
author:
  name: 'Kamran Ahmed'
  url: 'https://twitter.com/kamrify'
  imageUrl: '/authors/kamranahmedse.jpeg'
seo:
  title: 'Basic Authentication - roadmap.sh'
  description: 'Understand what is basic authentication and how it is implemented'
isNew: false
type: 'visual'
date: 2021-05-19
sitemap:
  priority: 0.7
  changefreq: 'weekly'
tags:
  - 'guide'
  - 'visual-guide'
  - 'guide-sitemap'
---

[![Basic Authentication](/guides/basic-authentication.png)](/guides/basic-authentication.png)
