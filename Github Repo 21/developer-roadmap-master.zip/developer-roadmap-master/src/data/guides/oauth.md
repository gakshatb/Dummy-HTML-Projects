---
title: 'OAuth — Open Authorization'
description: 'Learn and understand what is OAuth and how it works'
author:
  name: 'Kamran Ahmed'
  url: 'https://twitter.com/kamrify'
  imageUrl: '/authors/kamranahmedse.jpeg'
seo:
  title: 'OAuth — Open Authorization - roadmap.sh'
  description: 'Learn and understand what is OAuth and how it works'
isNew: false
type: 'visual'
date: 2021-06-28
sitemap:
  priority: 0.7
  changefreq: 'weekly'
tags:
  - 'guide'
  - 'visual-guide'
  - 'guide-sitemap'
---

[![OAuth - Open Authorization](/guides/oauth.png)](/guides/oauth.png)
