---
title: 'Character Encodings'
description: 'Covers the basics of character encodings and explains ASCII vs Unicode'
author:
  name: 'Kamran Ahmed'
  url: 'https://twitter.com/kamrify'
  imageUrl: '/authors/kamranahmedse.jpeg'
seo:
  title: 'Character Encodings - roadmap.sh'
  description: 'Covers the basics of character encodings and explains ASCII vs Unicode'
isNew: false
type: 'visual'
date: 2021-05-14
sitemap:
  priority: 0.7
  changefreq: 'weekly'
tags:
  - 'guide'
  - 'visual-guide'
  - 'guide-sitemap'
---

[![Character Encodings](/guides/character-encodings.png)](/guides/character-encodings.png)
