---
title: 'JWT Authentication'
description: 'Understand what is JWT authentication and how is it implemented'
author:
  name: 'Kamran Ahmed'
  url: 'https://twitter.com/kamrify'
  imageUrl: '/authors/kamranahmedse.jpeg'
seo:
  title: 'JWT Authentication - roadmap.sh'
  description: 'Understand what is JWT authentication and how is it implemented'
isNew: false
type: 'visual'
date: 2021-06-20
sitemap:
  priority: 0.7
  changefreq: 'weekly'
tags:
  - 'guide'
  - 'visual-guide'
  - 'guide-sitemap'
---

[![JWT Authentication](/guides/jwt-authentication.png)](/guides/jwt-authentication.png)
