# Avoid FS Mounts

> Avoid filesystem mounts (FUSE, etc).

I've found them to be about as reliable as a large government department when used in critical applications. Use the SDK instead.
