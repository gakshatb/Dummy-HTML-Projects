# Release EIPs

> Don't keep unassociated Elastic IPs.

You get charged for any Elastic IPs you have created but not associated with an instance, so make sure you don't keep them around once you're done with them.
