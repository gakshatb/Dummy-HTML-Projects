# Failover Event Subscription

> Set up event subscriptions for failover.

If you're using a Multi-AZ setup, this is one of those things you might not think about which ends up being incredibly useful when you do need it.
