# Turn Debug Mode Off

> Make sure to turn the debug mode off in production

Debug mode is a feature that is used to help developers debug their code. It is not meant to be used in production. It can expose sensitive information about the application and the server it is running on. Make sure to turn debug mode off in production.
