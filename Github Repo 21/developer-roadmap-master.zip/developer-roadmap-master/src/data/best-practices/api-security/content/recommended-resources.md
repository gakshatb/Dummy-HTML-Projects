# Recommended Resources

Have a look at the following resources for more information on API security:

- [Collection of Resources for Building APIs](https://github.com/yosriady/awesome-api-devtools)
- [CS253: Web Security](https://www.youtube.com/watch?v=5JJrJGZ_LjM&list=PL1y1iaEtjSYiiSGVlL1cHsXN_kvJOOhu-)
- [Securing Web Applications](https://www.youtube.com/watch?v=WlmKwIe9z1Q)
- [MIT 6.858: Computer Systems Security](https://www.youtube.com/watch?v=GqmQg-cszw4&list=PLUl4u3cNGP62K2DjQLRxDNRi0z2IRWnNh)
