# Use CDN for Uploads

> Use CDN for file uploads

Using a Content Delivery Network (CDN) for file uploads can make an API more secure by offloading the file upload traffic from the API server and reducing the risk of DDoS attacks.
