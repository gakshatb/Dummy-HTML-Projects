# Avoid Client-Side Encryption

> Use server-side encryption instead of client-side encryption

Client-side encryption is not recommended because client side codebase can be easily reverse engineered which can lead to the exposure of encryption algorithms.
