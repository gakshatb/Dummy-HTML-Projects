# Prefer Vector Images

> Prefer using vector image rather than bitmap images (when possible).

Vector images (SVG) tend to be smaller than images and SVG's are responsive and scale perfectly. These images can be animated and modified by CSS.
