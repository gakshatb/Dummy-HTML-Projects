# Minimize HTTP Requests

> Always ensure that every file requested are essential for your website or application.

- [Combine external CSS](https://varvy.com/pagespeed/combine-external-css.html)
- [Combine external JavaScript](https://varvy.com/pagespeed/combine-external-javascript.html)
