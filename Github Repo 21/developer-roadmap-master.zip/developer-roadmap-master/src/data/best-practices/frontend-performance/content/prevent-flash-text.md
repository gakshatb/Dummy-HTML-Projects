# Prevent Flash Text

> Avoid transparent text until the Webfont is loaded

- [`font-display` for the Masses](https://css-tricks.com/font-display-masses/)
- [CSS font-display: The Future of Font Rendering on the Web](https://www.sitepoint.com/css-font-display-future-font-rendering-web/)
