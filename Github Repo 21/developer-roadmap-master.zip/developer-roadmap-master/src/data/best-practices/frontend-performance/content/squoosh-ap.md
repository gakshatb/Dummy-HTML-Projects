# Squoosh.app

Squoosh.app is a web app that allows you to compress images using a variety of codecs. It is built by Google Chrome team and is open source.

- [Squoosh.app](https://squoosh.app/)
