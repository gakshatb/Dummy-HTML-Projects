# Page Speed Insights

Page Speed Insights is a free tool from Google that analyzes the performance of a web page and provides suggestions for improvements.

- [Page Speed Insights](https://pagespeed.web.dev/)
