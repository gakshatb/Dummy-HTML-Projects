# Keep TTFB < 1.3s

Reduce as much as you can the time your browser waits before receiving data.

- [What is Waiting (TTFB) in DevTools, and what to do about it](https://scaleyourcode.com/blog/article/27)
- [Monitoring your servers with free tools is easy](https://scaleyourcode.com/blog/article/7)
- [Time to First Byte (TTFB)](https://varvy.com/pagespeed/ttfb.html)
- [Global latency testing tool](https://latency.apex.sh)
