# Antolatu zure aplikazioa geruzatan, mantendu Express bere esparruaren barruan

<br/><br/>

### Osagaien kodea geruzatan banandu: web, zerbitzuak, eta Datuen Sarbide Geruza (DSG) (Ingelesez Data Access Layer, DAL)

![alt text](../../assets/images/structurebycomponents.PNG "Osagaien kodea geruzatan banandu")

<br/><br/>

### Minutu bateko azalpena: geruzak nahastearen eragozpena

![alt text](../../assets/images/keepexpressinweb.gif "Geruzak nahastearen eragozpena")
