### Index

* [Dil Bağımsız](#dil-bağımsız)
* [JavaScript](#javascript)
* [Ruby](#ruby)


### Dil Bağımsız

* [codefiction](https://codefiction.tech) (podcast)
* [devPod](https://devpod.org) (screencast)
* [kodpod](https://kodpod.live) (podcast)
* [Trendyol Tech Podcasts](https://trendyol.simplecast.com) (podcast)


### JavaScript

* [null podcast](https://soundcloud.com/nullpodcast) (podcast)


### Ruby

* [Yakut](https://www.youtube.com/playlist?list=PLEWqXxI7lAZIHZ4s3fcuy1UmF_YiQkZpi) (screencast)
