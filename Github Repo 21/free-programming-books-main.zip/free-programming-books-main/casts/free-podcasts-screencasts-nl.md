### Podcasts

* [Code Klets](https://open.spotify.com/show/0Sf8c3aGZmtGiNUEwgDTSu?si=bc273e44deae4584) - Bernard, Jonny, Kishen, Pauline, Wouter & Saber (podcast)
* [TDS Team](https://open.spotify.com/show/63diy2DtpHzQfeNVxAPZgU) - The TDS team (podcast)
