### Index

* [DevOps](#devops)
* [FOSS](#foss)


### DevOps

* [DevOps With Zack](https://anchor.fm/arshad-zackeriya) - Arshad Zackeriya


### FOSS

* [SLIIT FOSSCAST](https://anchor.fm/sliit-foss-community) - SLIIT FOSS Community
