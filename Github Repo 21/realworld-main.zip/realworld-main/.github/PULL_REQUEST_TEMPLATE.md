<!-- RealWorld is currently testing GitHub Copilot for Pull Requests, please leave this template unchanged -->

## Summary

copilot:summary

## Details

copilot:walkthrough
