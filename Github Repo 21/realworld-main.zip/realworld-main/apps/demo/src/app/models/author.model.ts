export interface Author {
  username: string;
  bio: string;
  image: string;
  following: boolean;
}
