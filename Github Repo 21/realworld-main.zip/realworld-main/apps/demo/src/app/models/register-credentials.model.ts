export interface RegisterCredentials {
  username: string;
  email: string;
  password: string;
}
