export interface SearchParams {
  limit?: number;
  offset?: number;
  author?: string;
  tag?: string;
  favorited?: string;
}
