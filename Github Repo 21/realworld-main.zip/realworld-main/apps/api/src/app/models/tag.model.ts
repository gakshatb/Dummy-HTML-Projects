export interface Tag {
  name: string;
}
