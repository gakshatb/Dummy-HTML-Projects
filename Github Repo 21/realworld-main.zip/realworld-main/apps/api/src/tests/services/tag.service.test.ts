describe('TagService', () => {
  describe('getTags', () => {
    // TODO : prismaMock.tag.groupBy.mockResolvedValue(mockedResponse) doesn't work
    test.todo('should return a list of strings');
  });
});
