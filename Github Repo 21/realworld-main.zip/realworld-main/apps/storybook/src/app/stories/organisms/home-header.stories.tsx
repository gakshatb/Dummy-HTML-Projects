export default {
  title: 'Organisms/Home Header',
  parameters: {
    layout: 'fullscreen',
  },
};

export const HomeHeader = () => (
  <section className="rw-home-header">
    <img className="rw-avatar-xxl rw-home-header__cover" src="energy.png" alt="user avatar" />
  </section>
);
