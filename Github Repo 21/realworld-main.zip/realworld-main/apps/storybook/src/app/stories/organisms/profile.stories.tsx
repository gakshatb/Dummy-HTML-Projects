export default {
  title: 'Organisms/Profile',
};

export const Profile = () => <></>;
