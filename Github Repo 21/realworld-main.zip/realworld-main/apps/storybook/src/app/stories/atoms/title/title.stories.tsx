export default {
  title: 'Atoms/Title',
};

export const TitleDefault = {
  render: () => <h1 className="rw-page-title">Create account</h1>,
};
