export default {
  title: 'Organisms/Article',
};

export const Article = () => <></>;
