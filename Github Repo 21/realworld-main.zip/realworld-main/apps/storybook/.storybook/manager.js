import { addons } from '@storybook/manager-api';

addons.setConfig({
  showPanel: false,
});
