---
sidebar_position: 1
---

# Introduction

All backend implementations need to adhere to our [API spec](https://github.com/gothinkster/realworld/tree/main/api).

For your convenience, we have a [Postman collection](https://github.com/gothinkster/realworld/blob/main/api/Conduit.postman_collection.json) that you can use to test your API endpoints as you build your app.

You can also test your endpoints using [Cypress API tests](https://github.com/gothinkster/realworld/tree/main/apps/api-testing-cypress) which cover the functionality in more detail.

Check out our [starter kit](https://github.com/gothinkster/realworld-starter-kit) to create a new implementation, please read [references to the API specs & testing](https://realworld-docs.netlify.app/docs/specs/backend-specs/introduction) required for creating a new backend.
