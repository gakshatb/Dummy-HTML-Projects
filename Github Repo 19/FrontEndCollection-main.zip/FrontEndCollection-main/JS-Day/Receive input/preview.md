
![Jan-07-2022 23-14-23](https://user-images.githubusercontent.com/37787994/148633992-ccb4e930-0a70-4b38-aa55-7420859ac182.gif)


<img width="188" alt="Screen Shot 2022-01-07 at 23 19 39" src="https://user-images.githubusercontent.com/37787994/148634004-c5d5a70b-cbe1-43be-9bc4-79668af08e9a.png">

[Code](https://github.com/cheatsheet1999/FrontEndCollection/blob/main/JS-Day/Receive%20input/app.js)
