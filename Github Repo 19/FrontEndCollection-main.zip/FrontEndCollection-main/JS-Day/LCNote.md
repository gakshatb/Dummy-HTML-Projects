## 07-14
1, 13, 146, 56

## 07-15
1249, 200，53

## 07-16
20, 42, 680

## 07-17
3, 560, 121

## 07-18
2, 811

## 07-19
1762, 14

## 07-20
15, 253

## 07-21
215

## 07-22
5

## 07-23 (Review)
(1) **Hashmap, return [i, map.get(nums[i))]**   
(13) **curr = [map[s[i]] next = [map[s[i + 1]]]**    
(56) **start = intervals[i][0] end = intervals[i][1]**   
(1249) **if(s[i] === "(") stack.push(i)**    
(200) **DFS**     
(53)**prev = Math.max(prev + nums[i], nums[i]);**       
(20) **s = s.split("") switch(s[i])**  
(42) lMax = 0, rMax = 0; l = 0, r = height.length - 1

## 07-24 (Review)
(680) **low = 0, high = s.length - 1 while(low<high) if(s[low] !== s[high])**        
(3) **visited.delete(s[slow]); visited.add(s[fast])**      
(560) **map.set(0, 1);**      
(121) **min = Math.min(min, prices[i] max = Math.max(max, max - prices[i]))**     
(2) **let head = new ListNode(0) let res = head**       
(811) **let [visits, domain] = cpdomains[i].split(" "); let subdomains = domain.split(".");**        
(14) **if(str[i] !== strs[0][i]) {return str.slice(0, i);}**    

## 07-25 (Review)
(1762) **while(res.length && heights[i] >= heights(res[res.length - 1]))**          
(15) **nSum(arr.slice(i + 1), [...result, arr[i]], target - arr[i], n - 1);**       
(253) **let starts = intervals.map(a => a[0]).sort((a, b) => a - b); let ends = intervals.map(a => a[1]).sort((a, b) => a - b);**   

## 07-26 (Review)
(215) **return quickSelect(nums, 0, nums.length - 1, k);**      
(5) **while(i >= 0 && j < s.length && s[i] === s[j])**    

## 07/27 
71, 31

## 07/28
394, 22

## 07/29
227

## 07/30
79
## 07/31
11, 17


## 08/01 - 08/02
Review
71, 31, 394, 22,
227, 79, 11, 17

## 08/03
49, 217

## 08/04
923, 1268

## 08/05
1209 (289)

## 08/06
(298)

## 08/07
94, interview

## 08/08
54

## 08/09
347

## 08/10
49

## 08/12
1048

## 08/13
1091

## 08/23
48

## 08/24
1010

## 08/25
21, 50

## 08/26
1207

## 08/29
1 2 3 5

## 08/30
206, 283, 6

## 08/31
7, 9, 11

## 09/01
12, 13, 14, 15

## 09/02
16, 17

## 09/03
18, 19

## 09/04
20, 21, 22

## 09/05
24, 26, 27

## 09/06
28, 31

## 09/07
33, 34, 35
## 09/05
24, 26, 27

## 09/06
28, 31

## 09/07
33, 34, 35

## 09/08
36

## 09/09
38

## 09/10
39

## 09/11
40

## 09/12
42

## 09/13
43

## 09/14
45
