
## Demo

https://codesandbox.io/s/bin2dec-version1-j2h94t
