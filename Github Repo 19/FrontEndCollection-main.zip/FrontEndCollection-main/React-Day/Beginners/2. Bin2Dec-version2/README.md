## DEMO

https://codesandbox.io/s/bin2dec-version2-smpsu6?file=/src/App.js:0-1301
