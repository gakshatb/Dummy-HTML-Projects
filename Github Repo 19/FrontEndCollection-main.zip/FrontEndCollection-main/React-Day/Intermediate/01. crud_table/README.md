![crud-table](https://user-images.githubusercontent.com/37787994/188299808-6dff25a5-b0a1-4434-bb18-e095b7c4d6fd.gif)
