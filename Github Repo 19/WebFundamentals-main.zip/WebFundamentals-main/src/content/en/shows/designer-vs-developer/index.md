project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Welcome to Designer Vs Developer, a show that tries to solve the challenges faced in industry by opening a conversation between the two, providing take aways, solutions to workflows, and tools & discussions on everyday struggles. 

{# wf_updated_on: 2018-02-27 #}
{# wf_published_on: 2017-03-09 #}
{# wf_blink_components: N/A #}

# Designer Vs Developer {: .page-title }

<img src="images/dvd-s1-ep01.png" class="attempt-right">

**Welcome to Designer Vs Developer** A show that tries to solve the challenges 
faced in industry by opening a conversation between the two, providing take
aways, solutions to workflows, and tools & discussions on everyday struggles. 

[YouTube](https://www.youtube.com/playlist?list=PLNYkxOF6rcIC60856GnLEV5GQXMxc9ByJ)

[Podcast](podcast/)
