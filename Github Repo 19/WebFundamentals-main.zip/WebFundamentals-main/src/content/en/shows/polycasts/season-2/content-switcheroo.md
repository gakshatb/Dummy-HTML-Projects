project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Presto Change-O! Update the sections in your single page app using core-pages.

{# wf_updated_on: 2015-03-05 #}
{# wf_published_on: 2015-03-05 #}
{# wf_youtube_id: 6x2A9UgLqEw #}

# Content Switcheroo with Core-Pages {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="6x2A9UgLqEw"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Presto Change-O! Update the sections in your single page app using core-pages.

## Read More

- [The Awesome Power of Auto-Binding Templates](/web/shows/polycasts/season-2/awesome-power-of-auto-binding)
- [Core Drawer Panel](/web/shows/polycasts/season-1/core-drawer-panel)
- [Core Header Panel](/web/shows/polycasts/season-1/core-header-panel)
- [Core Toolbar](/web/shows/polycasts/season-1/core-toolbar)
