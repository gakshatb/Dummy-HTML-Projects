project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Super charge your app with Polymer data bindings.

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: 82LfXCeuaOo #}

# The Awesome Power of Auto-Binding Templates {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="82LfXCeuaOo"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Super charge your app with Polymer data bindings.

## Read More

- [Polycasts: Core Drawer Panel](/web/shows/polycasts/season-1/core-drawer-panel)
- [Polycasts: Core Header Panel](/web/shows/shows/polycasts/season-1/core-header-panel)
- [Polycasts: Core Toolbar](/web/shows/shows/polycasts/season-1/core-toolbar)
