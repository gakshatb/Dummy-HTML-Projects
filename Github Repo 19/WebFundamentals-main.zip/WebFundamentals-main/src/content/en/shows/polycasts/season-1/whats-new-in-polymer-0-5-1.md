project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: In today's video we take a look at the current stable release of Polymer, v0.5.1, and cover some of the changes that this update brings with it.

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: Iq8TdPJSQMI #}

# What's new in Polymer 0.5.1 {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Iq8TdPJSQMI"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


In today's video we take a look at the current stable release of Polymer, v0.5.1, and cover some of the changes that this update brings with it.

## Read More

- [Blog Post](https://blog.polymer-project.org/releases/2014/11/12/release-0.5.1/)
