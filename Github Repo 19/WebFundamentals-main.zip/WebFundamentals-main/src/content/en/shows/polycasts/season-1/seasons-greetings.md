project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Hey there Polycasters! We wanted to take a moment to wish you all very happy holidays and thank you so much for checking out the first season. In today's episode we have highlights from the Chrome Dev Summit and a survey so *you* can let us know what content you'd like to see in the second season.

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: aDQUYs-0hxQ #}

# Season's greetings! {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="aDQUYs-0hxQ"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Hey there Polycasters! We wanted to take a moment to wish you all very happy holidays and thank you so much for checking out the first season. In today's episode we have highlights from the Chrome Dev Summit and a survey so *you* can let us know what content you'd like to see in the second season.

## Read More

- [Easy composition and reuse with Web Components](//goo.gl/Jq2b3l)
- [Polymer: State of the Union](//goo.gl/ZnsHMO)
- [Let's build some apps with Polymer!](//goo.gl/Uf0DfQ)
