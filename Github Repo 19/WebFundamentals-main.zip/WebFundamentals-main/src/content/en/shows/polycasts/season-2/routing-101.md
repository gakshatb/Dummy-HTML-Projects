project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Routing in Polymer, revealed! Get on the path to single page app goodness with this nugget of wisdom.

{# wf_updated_on: 2015-03-05 #}
{# wf_published_on: 2015-03-05 #}
{# wf_youtube_id: iDQqP5Yyczg #}

# Routing 101 {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="iDQqP5Yyczg"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Routing in Polymer, revealed! Get on the path to single page app goodness with this nugget of wisdom.

## Read More

- [Page.js, JavaScript router](https://github.com/visionmedia/page.js)
- [Content Switcheroo with Core-Pages](/web/shows/polycasts/season-2/content-switcheroo)
- [The Awesome Power of Auto-Binding Templates](/web/shows/polycasts/season-2/awesome-power-of-auto-binding)
- [Core Drawer Panel](/web/shows/polycasts/season-1/core-drawer-panel)

