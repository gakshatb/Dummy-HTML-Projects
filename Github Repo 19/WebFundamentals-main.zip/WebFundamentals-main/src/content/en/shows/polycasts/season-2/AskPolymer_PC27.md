project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: We’re trying something new here on Polycasts. If you have questions for the team send them in on a social network of your choosing with the hashtag #AskPolymer and we’ll try to answer them on air!

{# wf_updated_on: 2015-09-29 #}
{# wf_published_on: 2015-09-29 #}
{# wf_youtube_id: D7ZSMw_qm8Q #}

# #AskPolymer -- Polycasts #27 {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="D7ZSMw_qm8Q"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


We’re trying something new here on Polycasts. If you have questions for the team send them in on a social network of your choosing with the hashtag #AskPolymer and we’ll try to answer them on air!

## Read More

### Addy Osmani explains PolyGit
<https://www.youtube.com/watch?v=LMqM4PfrFxs&feature=youtu.be&t=26m54s>

### PolyGit.org
<https://polygit.org/>

### iron-ajax...wat?!
<https://www.youtube.com/watch?v=k1eR_3KqJms&list=PLNYkxOF6rcIDdS7HWIC_BYRunV6MHs5xo&index=1>

### Polymer Team responds to HTML Imports questions
<https://youtu.be/mw0ozps3jLM?t=19m46s>

- Polymer Slack: <http://bit.ly/polymerslack>
- [Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel
