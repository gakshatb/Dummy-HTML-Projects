project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Last week you learned how to use a router in your Polymer app. This week we're doing it again, using nothing but HTML!

{# wf_updated_on: 2015-03-05 #}
{# wf_published_on: 2015-03-05 #}
{# wf_youtube_id: -67kb7poIT8 #}

# Moar routing with... more-routing {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="-67kb7poIT8"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Last week you learned how to use a router in your Polymer app. This week we're doing it again, using nothing but HTML!

## Read More

- [more-routing element](https://github.com/polymore/more-routing)
- [Routing 101](/web/shows/polycasts/season-2/routing-101)
- [Content Switcheroo with Core-Pages](/web/shows/polycasts/season-2/content-switcheroo)
- [The Awesome Power of Auto-Binding Templates](/web/shows/polycasts/season-2/awesome-power-of-auto-binding)
