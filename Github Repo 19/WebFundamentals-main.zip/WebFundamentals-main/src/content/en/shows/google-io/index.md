project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-03-05 #}
{# wf_published_on: 2015-03-05 #}

# Google IO {: .page-title }


<img src="../imgs/googleio_rect.jpg" class="attempt-right">

All the videos from all of the Google IO's that we have on record.
