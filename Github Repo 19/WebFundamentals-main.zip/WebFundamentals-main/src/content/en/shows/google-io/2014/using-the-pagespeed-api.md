project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: How to integrate the PageSpeed Insights API into your work flow, understanding what it can do and how it can help you to ensure you've got a great mobile experience.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: vPfz2VwIryk #}

# Using the PageSpeed API {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="vPfz2VwIryk"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


How to integrate the PageSpeed Insights API into your work flow, understanding what it can do and how it can help you to ensure you've got a great mobile experience.
