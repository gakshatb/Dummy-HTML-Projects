project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: An overview of the new features of WebView that shipped in the KitKat/L release of Android.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: 0tH-KHvifMk #}

# What's new in WebView {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="0tH-KHvifMk"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


An overview of the new features of WebView that shipped in the KitKat/L release of Android.
