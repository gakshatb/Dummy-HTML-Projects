project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Tips, tricks and practices to encode a video into WebM using VPx codecs for delivery across the web and on Android.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: o-TAyIQBOuA #}

# Demystifying encodes and decodes of WebM {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="o-TAyIQBOuA"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Tips, tricks and practices to encode a video into WebM using VPx codecs for delivery across the web and on Android.
