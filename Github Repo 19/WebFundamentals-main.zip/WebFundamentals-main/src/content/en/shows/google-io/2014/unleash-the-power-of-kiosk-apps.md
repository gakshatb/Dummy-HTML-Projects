project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: With Single App kiosk mode, developers can build powerful Kiosk apps that convert Chromeboxes into purpose built devices. The use cases are phenomenal from Digital Signage in Airports and Restaurants to ATM machines in Banks.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: aGvFbBt-LNA #}

# Unleash the power of Kiosk Apps {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="aGvFbBt-LNA"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


With Single App kiosk mode, developers can build powerful Kiosk apps that convert Chromeboxes into purpose built devices. The use cases are phenomenal from Digital Signage in Airports and Restaurants to ATM machines in Banks.
