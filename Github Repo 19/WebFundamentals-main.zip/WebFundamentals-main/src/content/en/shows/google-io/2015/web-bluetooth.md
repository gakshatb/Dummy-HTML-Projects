project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-07-05 #}
{# wf_published_on: 2015-07-05 #}
{# wf_youtube_id: I3obFcCw8mk #}

# Web Bluetooth {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="I3obFcCw8mk"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Giovanni Ortuño gives us an overview of Web Bluetooth. Web Bluetooth is part of
the continued effort to expose powerful mobile features to developers and users.
