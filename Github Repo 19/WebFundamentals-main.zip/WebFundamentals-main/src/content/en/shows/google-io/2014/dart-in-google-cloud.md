project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Dart's VM is a full featured server, with support for HTTP, SSL, Web sockets, and more. Learn how to build server apps with Dart and deploy (and scale!) to Google's Cloud.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: UqolCJsvD_g #}

# Dart in Google Cloud {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="UqolCJsvD_g"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Dart's VM is a full featured server, with support for HTTP, SSL, Web sockets, and more. Learn how to build server apps with Dart and deploy (and scale!) to Google's Cloud.
