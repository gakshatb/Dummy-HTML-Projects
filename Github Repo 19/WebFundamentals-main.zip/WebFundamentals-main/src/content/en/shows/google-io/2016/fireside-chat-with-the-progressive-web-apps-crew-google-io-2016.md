project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-05-19 #}
{# wf_published_on: 2016-05-19 #}
{# wf_youtube_id: Sy4oH8JZuJQ #}

# Fireside Chat with the Progressive Web Apps Crew - Google I/O 2016 {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Sy4oH8JZuJQ"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Come meet some of the team building the Progressive Web App platform in the Chrome team.  We'll take your questions and talk about where we see the future taking us.

* Watch more Chrome talks at I/O 2016 here: <https://goo.gl/JoMLpB> 
* See all the talks from Google I/O 2016 here: <https://goo.gl/olw6kV>
* Subscribe to the Chrome Developers channel at <https://goo.gl/LLLNvf>

`#io16` `#GoogleIO` `#GoogleIO2016`
