project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: We've launched Chrome Apps to consumers. It's available on ChromeOS, Win, Mac and Linux! We can talk about new and exciting features since last year's Google IO: Managed In-App Payments, Unified GCM, enhanced Media Gallery API, the Mac App Launcher and more. We can showcase forward looking ideas such as ephemeral apps. We can also talk about developer adoption externally and within Google for first party apps.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: IXDSPlVZRJE #}

# Chrome Apps: State of the Union 2014 {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="IXDSPlVZRJE"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


We've launched Chrome Apps to consumers. It's available on ChromeOS, Win, Mac and Linux! We can talk about new and exciting features since last year's Google IO: Managed In-App Payments, Unified GCM, enhanced Media Gallery API, the Mac App Launcher and more. We can showcase forward looking ideas such as ephemeral apps. We can also talk about developer adoption externally and within Google for first party apps.
