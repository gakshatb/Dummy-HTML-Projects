project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: How to build responsive sites for the multi-device web. Topics include responsive, viewport, media queries, and some layout patterns. This content rolls up to the webshine project

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: oK09n_PGhTo #}

# Building sites for the multi-device web {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="oK09n_PGhTo"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


How to build responsive sites for the multi-device web. Topics include responsive, viewport, media queries, and some layout patterns. This content rolls up to the webshine project
