project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-05-27 #}
{# wf_published_on: 2015-05-27 #}
{# wf_youtube_id: fD2As5RmM8Q #}

# Polymer and modern web APIs: In production at Google scale {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="fD2As5RmM8Q"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>

Addy Osmani; Eric Bidelman; Matthew McNulty; Taylor Savage

The latest version of Polymer is fast and lean. Learn how teams at Google have successfully 
launched sites using Polymer and the latest platform APIs: Web Animations, service workers 
for offline and push notifications, and material design. And if you're new to Polymer we'll 
show you how to get started building mobile-first apps.
