project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Tap Target Size, Touch Feedback, and Touch Events; everything you need to know to build touch support into your web app.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: Rwc4fHUnGuU #}

# Touch in a Web App? No Problem {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Rwc4fHUnGuU"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Tap Target Size, Touch Feedback, and Touch Events; everything you need to know to build touch support into your web app.
