project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: This session will demonstrate the music-making capabilities in the web platform via the Web Audio and Web MIDI APIs, across both mobile and desktop.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: Wvx-BWKL0u4 #}

# Making Music with the Web Platform {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Wvx-BWKL0u4"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


This session will demonstrate the music-making capabilities in the web platform via the Web Audio and Web MIDI APIs, across both mobile and desktop.
