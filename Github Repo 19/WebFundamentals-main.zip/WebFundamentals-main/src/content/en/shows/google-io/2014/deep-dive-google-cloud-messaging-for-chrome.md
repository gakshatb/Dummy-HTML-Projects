project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: A deep dive into cross-platform messaging, with a focus on Chrome's API and implementations.  [ed: similar talk from android]

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: g_zkOOWsmco #}

# Deep dive: Google Cloud Messaging for Chrome {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="g_zkOOWsmco"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


A deep dive into cross-platform messaging, with a focus on Chrome's API and implementations.  [ed: similar talk from android]
