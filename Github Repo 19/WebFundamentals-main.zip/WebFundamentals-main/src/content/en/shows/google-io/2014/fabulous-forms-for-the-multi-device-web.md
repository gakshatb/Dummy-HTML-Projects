project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: How to build great forms that work beautiful on the multi-device web, content includes labeling, auto-complete, requestAutoComplete, validation, semantic input types, and best practices.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: iYYHRwLqrKM #}

# Fabulous Forms for the multi-device web {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="iYYHRwLqrKM"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


How to build great forms that work beautiful on the multi-device web, content includes labeling, auto-complete, requestAutoComplete, validation, semantic input types, and best practices.
