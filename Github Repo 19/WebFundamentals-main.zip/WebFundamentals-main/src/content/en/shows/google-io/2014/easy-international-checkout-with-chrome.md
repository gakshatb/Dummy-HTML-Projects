project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Chrome's requestAutocomplete can help web and mobile web developers breeze through the process of creating a truly internationalized checkout experience for their users. Find out why it matters and see it in action.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: ljYeHwGgzQk #}

# Easy International Checkout with Chrome {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="ljYeHwGgzQk"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Chrome's requestAutocomplete can help web and mobile web developers breeze through the process of creating a truly internationalized checkout experience for their users. Find out why it matters and see it in action.
