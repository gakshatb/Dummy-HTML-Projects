project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: For developers who want to use responsive images today, what can they do? We'll cover the current state like picture, img src, srcset, etc and include suggestions around art direction.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: vpRsLPI400U #}

# Responsive images today {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="vpRsLPI400U"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


For developers who want to use responsive images today, what can they do? We'll cover the current state like picture, img src, srcset, etc and include suggestions around art direction.
