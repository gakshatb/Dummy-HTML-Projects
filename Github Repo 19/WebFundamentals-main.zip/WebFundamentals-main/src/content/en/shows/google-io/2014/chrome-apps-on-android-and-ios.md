project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Chrome Apps can now run on both Android and iOS using a toolchain based on Apache Cordova.  This provides developers a strong incentive to adopt web technology to build native-like apps targeting desktop as well as mobile platforms.  We'll be talking about the ease of development and the differentiating capabilities provided by the platform.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: nU4lvgTrjFI #}

# Chrome Apps on Android and iOS {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="nU4lvgTrjFI"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Chrome Apps can now run on both Android and iOS using a toolchain based on Apache Cordova. 

This provides developers a strong incentive to adopt web technology to build native-like apps targeting desktop as well as mobile platforms. 

We'll be talking about the ease of development and the differentiating capabilities provided by the platform.
