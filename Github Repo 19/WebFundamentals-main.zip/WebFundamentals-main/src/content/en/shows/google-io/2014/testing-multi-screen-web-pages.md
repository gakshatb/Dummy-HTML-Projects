project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: So you need to build a responsive site. We'll look at how you set up your dev environment to best test across multiple devices and screen sizes.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: vsmU09PoYy4 #}

# Testing multi-screen web pages {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="vsmU09PoYy4"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


So you need to build a responsive site. We'll look at how you set up your dev environment to best test across multiple devices and screen sizes.
