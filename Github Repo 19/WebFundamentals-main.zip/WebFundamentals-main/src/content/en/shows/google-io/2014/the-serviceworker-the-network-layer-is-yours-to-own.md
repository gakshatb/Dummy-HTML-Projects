project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Introducing ServiceWorker, the API that gives you full control over HTTP caching, request, and forms the basis for push messaging, alarms, geofencing and background sync.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: 4uQMl7mFB6g #}

# The ServiceWorker: The network layer is yours to own {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="4uQMl7mFB6g"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Introducing ServiceWorker, the API that gives you full control over HTTP caching, request, and forms the basis for push messaging, alarms, geofencing and background sync.
