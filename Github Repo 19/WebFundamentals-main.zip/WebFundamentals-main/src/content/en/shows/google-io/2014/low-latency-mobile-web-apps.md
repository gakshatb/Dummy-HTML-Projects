project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Cover technical and product challenges in building seamless interactive experience on mobile phones and tablets. Introduce the best practices followed by news team in overcoming browser challenges.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: 5uF3925a974 #}

# Low Latency Mobile Web Apps {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="5uF3925a974"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Cover technical and product challenges in building seamless interactive experience on mobile phones and tablets. Introduce the best practices followed by news team in overcoming browser challenges.
