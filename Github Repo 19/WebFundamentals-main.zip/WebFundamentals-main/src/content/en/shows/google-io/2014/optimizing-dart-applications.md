project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Use the Dart VM's builtin Observatory tool to analyze and fix performances issues in Dart applications. Peer into a running VM and get real-time feedback on memory and CPU usage.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: Ww8ISWzZGRE #}

# Optimizing Dart Applications {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Ww8ISWzZGRE"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Use the Dart VM's builtin Observatory tool to analyze and fix performances issues in Dart applications. Peer into a running VM and get real-time feedback on memory and CPU usage.
