project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Learn how WebP can help reduce the load time of images through better image compression

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: rqXMwLbYEE4 #}

# Faster Loading Images with WebP {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="rqXMwLbYEE4"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Learn how WebP can help reduce the load time of images through better image compression
