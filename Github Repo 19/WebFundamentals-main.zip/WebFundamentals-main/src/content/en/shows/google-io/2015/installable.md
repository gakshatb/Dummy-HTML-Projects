project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-05-27 #}
{# wf_published_on: 2015-05-27 #}
{# wf_youtube_id: N1Bdu7ukN40 #}

# Installable Web Apps {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="N1Bdu7ukN40"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


You can make your web app an Installable Web App with only a few minor changes to your code. 
Installable Web Apps look and feel like installed native apps; they are launched from the home screen, 
hide the address bar, and use your brand colors to provide a great experience.
