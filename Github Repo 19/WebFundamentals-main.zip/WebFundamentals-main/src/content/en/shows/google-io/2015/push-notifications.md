project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-05-27 #}
{# wf_published_on: 2015-05-27 #}
{# wf_youtube_id: Z_K8QPQe6oM #}

# Push Notifications on the Open Web to increase engagement {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Z_K8QPQe6oM"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>

Push notifications are now available on the open web through a new set of web APIs and 
Michael van Ouwerkerk, an engineer on the Chrome team is going to show you how to add 
them to your web app so that you can vastly increase the engagement you have with 
your users.
