project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: We'll go over what has changed, improvements, what we are working on, and where we're headed next with the VP9 video codec.

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: xo_R40C7RTo #}

# Update on WebM/VP9 {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="xo_R40C7RTo"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


We'll go over what has changed, improvements, what we are working on, and where we're headed next with the VP9 video codec.
