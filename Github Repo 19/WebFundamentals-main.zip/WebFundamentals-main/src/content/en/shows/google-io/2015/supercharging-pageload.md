project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-05-27 #}
{# wf_published_on: 2015-05-27 #}
{# wf_youtube_id: d5_6yHixpsQ #}

# Supercharging page load {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="d5_6yHixpsQ"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>

Jake Archibald introduces how making simple changes to service worker can vastly improve 
the startup and load performance of your website.  In this video Jake shows how he has 
made his Wikipedia application not only work offline but amazingly performant too. 

[Demo](https://wiki-offline.jakearchibald.com)
