project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Native Client applications can now be developed and debugging in the browser online or offline! Take a tour of our sandboxed tools including: curl, vim, python, gcc, gdb, git!

{# wf_updated_on: 2015-03-29 #}
{# wf_published_on: 2015-03-29 #}
{# wf_youtube_id: OzNuzBDEWzk #}

# Building a NaCl app {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="OzNuzBDEWzk"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Native Client applications can now be developed and debugging in the browser online or offline! Take a tour of our sandboxed tools including: curl, vim, python, gcc, gdb, git!
