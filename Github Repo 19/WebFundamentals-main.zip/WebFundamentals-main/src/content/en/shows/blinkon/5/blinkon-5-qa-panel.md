project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-01-03 #}
{# wf_published_on: 2016-01-03 #}
{# wf_youtube_id: cHrRXY2GMus #}

# BlinkOn 5: Q&A Panel {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="cHrRXY2GMus"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


The panel: Jochen Eisinger, Laslo Gombos, Alex Komoroske, Philip Jagenstadt, Doug Stockwell, Kinuko Yasuda, Chris Harrelson, Dimitri Glazkov.

This was the Q&A session to end BlinkOn 5, a low-key conference for Blink contributors, held on November 10 and November 11, 2015 in Google’s San Francisco office. More details can be found at http://bit.ly/blinkon5
