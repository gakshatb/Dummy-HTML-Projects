project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-22 #}
{# wf_published_on: 2016-06-22 #}
{# wf_youtube_id: VITAyGT-CJI #}

# BlinkOn 6 Day 2 Talk 6: How we measure and optimize for RAIL in V8’s GC {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="VITAyGT-CJI"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Ulan Degenbaev, Michael Lippautz

Slides: https://docs.google.com/presentation/d/15EQ603eZWAnrf4i6QjPP7S3KF3NaL3aAaKhNUEatVzY/edit
