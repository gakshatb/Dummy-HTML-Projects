project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-22 #}
{# wf_published_on: 2016-06-22 #}
{# wf_youtube_id: WRFBJQCZAuo #}

# BlinkOn 6 Day 2 Talk 3: Blink Onion Soup {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="WRFBJQCZAuo"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Elliott Sprehn

Slides: https://docs.google.com/presentation/d/1Dpj4tpueCdne4MoRh6UOHrFTq3fdfz_yH5QGQInFCl4/edit
