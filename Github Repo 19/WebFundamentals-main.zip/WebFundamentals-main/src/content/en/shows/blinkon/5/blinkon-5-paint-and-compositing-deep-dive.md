project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-03-10 #}
{# wf_published_on: 2016-03-10 #}
{# wf_youtube_id: p4U9rfJkgdU #}

# BlinkOn 5: Paint and Compositing Deep Dive {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="p4U9rfJkgdU"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Chris Harrelson talking about Paint and Compositing in Chromium.

Slides: https://docs.google.com/presentation/d/1pbuEJPwbzlYKDEBqJU0D48IJnsN6-gtesvoJ016-rvo/edit#slide=id.p

This talk was given at BlinkOn 5, a low-key conference for Blink contributors, held on November 10 and November 11, 2015 in Google’s San Francisco office. More details can be found at http://bit.ly/blinkon5
