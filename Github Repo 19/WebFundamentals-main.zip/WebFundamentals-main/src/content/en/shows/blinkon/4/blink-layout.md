project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-05-12 #}
{# wf_published_on: 2015-05-12 #}
{# wf_youtube_id: Q2diuftFJKo #}

# Blink Layout {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Q2diuftFJKo"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Emil A Eklund gives an update on the Blink Layout team and their current projects. The talk include special attention to the team's progress around making text layout fast even in the hard cases.
