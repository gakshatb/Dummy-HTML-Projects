project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-01-03 #}
{# wf_published_on: 2016-01-03 #}
{# wf_youtube_id: hCyVlkxB5E8 #}

# BlinkOn 5: Blink Architecture & Layering {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="hCyVlkxB5E8"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Elliott Sprehn talks about the architecture & layering of the Blink project and how it may evolve in the future. 
Slides: https://docs.google.com/presentation/d/1Am42_Tqn0uqgep6Keoiko0MPMtTsXTbTt5mtA4Z-CwY/edit

This talk was given at BlinkOn 5, a low-key conference for Blink contributors, held on November 10 and November 11, 2015 in Google’s San Francisco office. More details can be found at http://bit.ly/blinkon5
