project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-01-03 #}
{# wf_published_on: 2016-01-03 #}
{# wf_youtube_id: imuqTHykuqg #}

# BlinkOn 5: Progressive Web Apps & Project Fizz {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="imuqTHykuqg"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Alex Russell talks about Progressive Web Apps and Chrome's project Fizz which works on the underlying technology.
Slides: https://docs.google.com/presentation/d/1tEjjaQbJMGdufII_n5_pix0--Aouft_c9Hwzg4ORDRA/edit

This talk was given at BlinkOn 5, a low-key conference for Blink contributors, held on November 10 and November 11, 2015 in Google’s San Francisco office. More details can be found at http://bit.ly/blinkon5
