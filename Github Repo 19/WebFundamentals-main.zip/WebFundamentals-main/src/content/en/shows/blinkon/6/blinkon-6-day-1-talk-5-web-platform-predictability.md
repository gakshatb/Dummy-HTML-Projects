project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-22 #}
{# wf_published_on: 2016-06-22 #}
{# wf_youtube_id: ipfPyM-Kwyk #}

# BlinkOn 6 Day 1 Talk 5: Web Platform Predictability {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="ipfPyM-Kwyk"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Rick Byers and Philip Jägenstedt

Slides: https://docs.google.com/presentation/d/1umK4QkfCvzicHVJKLNo2yDRyWSqQEamavW9QVFmugNY/preview
