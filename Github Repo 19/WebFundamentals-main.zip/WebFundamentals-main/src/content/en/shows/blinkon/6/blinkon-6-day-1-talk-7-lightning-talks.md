project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-22 #}
{# wf_published_on: 2016-06-22 #}
{# wf_youtube_id: PMDRfYw4UYQ #}

# BlinkOn 6 Day 1 Talk 7: Lightning Talks {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="PMDRfYw4UYQ"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


0:00 What makes scrolling slow? (Tim Dresser)
3:19 WebGL 2.0 (oetuaho, NVIDIA)
7:04 WebBluetooth (Jeffrey Yasskin)
10:47 WebUSB (Reilly Grant)
14:26 Recap of the Chrome Diversity Summit (Mike Lawther)
18:10 Web Fonts Updates (Takashi Toyoshima)
21:40 Web MIDI Updates (Takashi Toyoshima)
25:26 Scroll Anchoring (Steve Kobes)
28:21 Skia shared pointers (Florin Malita)
32:18 Predictability in performance measurements (Mircea Trofin)
36:09 Offline content past MHTML (Dmitry Titov)
39:47 Making best use of depot_tools (Andrii Shyshkalov)
43:20 Observer pattern (Stefan Zager)
46:49 Subsetting the Web (Ojan Vafai)
50:20 First meaningful paint metric (Kunihiko Sakamoto)
53:24 Tracing from V8 to Blink (Marcel Hlopko)
56:25 Making alert() dialogs behave (Avi Drissman)
58:33 Pointer Events (Navid Zolghadr)
1:01:25 Tracing v2 (Primiano Tucci)
1:04:53 Silent push and background service workers (Jennifer Harkness)
1:08:34 Oilpan (Keishi Hattori)
1:11:50 Chromium Code of Conduct (Erik Staab)
1:15:03 Testing Skia on Android with Swarming and Raspberry Pi (Stephan Altmueller)
1:18:17 Rendering pipeline throttling (Sami Kyostila)
1:21:15 Media Capture Depth Stream Extensions (Dongseong Hwang)
1:24:53 What's up with Slimming Paint (Chris Harrelson)
1:28:20 How to WTF::bind() pointers (Hiroshige Hayashizaki)
1:30:10 CSS4 user-select (Yoichi Osato)

Slides: https://docs.google.com/spreadsheets/d/1qRGB1Igy8rVWbWwNB6EDRBHMC--9i6n-bbO2m2WHfS8/edit
