project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-01-03 #}
{# wf_published_on: 2016-01-03 #}
{# wf_youtube_id: lqz_rXCoAIc #}

# BlinkOn 5: V8 Garbage Collection {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="lqz_rXCoAIc"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Hannes Payer talks about how the Blink project is reducing memory consumption and improving latency via the V8 Garbage Collector.
Slides: https://drive.google.com/file/d/0By9nsZ10MWBWRDhUTDZyb01oUkk/view

This talk was given at BlinkOn 5, a low-key conference for Blink contributors, held on November 10 and November 11, 2015 in Google’s San Francisco office. More details can be found at http://bit.ly/blinkon5
