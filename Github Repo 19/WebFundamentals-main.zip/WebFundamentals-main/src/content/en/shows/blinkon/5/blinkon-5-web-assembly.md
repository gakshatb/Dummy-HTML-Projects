project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-01-03 #}
{# wf_published_on: 2016-01-03 #}
{# wf_youtube_id: iCSAUHpPbiU #}

# BlinkOn 5: Web Assembly {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="iCSAUHpPbiU"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Nick Bray talks about Web Assembly (WASM) in the context of the Blink project.
Slides: https://docs.google.com/presentation/d/19gdTwicIb-tkZ1bg8117pKVJ5oLnBbf1FsRUfDuFSQg/edit

This talk was given at BlinkOn 5, a low-key conference for Blink contributors, held on November 10 and November 11, 2015 in Google’s San Francisco office. More details can be found at http://bit.ly/blinkon5
