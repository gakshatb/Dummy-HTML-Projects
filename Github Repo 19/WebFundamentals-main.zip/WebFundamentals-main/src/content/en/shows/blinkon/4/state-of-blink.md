project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Kent Tamura & Doug Stockwell give an update on the state of Chrome's rendering engine Blink.

{# wf_updated_on: 2015-05-12 #}
{# wf_published_on: 2015-05-12 #}
{# wf_youtube_id: Ap5sWqtCE2o #}

# State of Blink {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Ap5sWqtCE2o"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Kent Tamura & Doug Stockwell give an update on the state of Chrome's rendering engine Blink.
