project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-01-03 #}
{# wf_published_on: 2016-01-03 #}
{# wf_youtube_id: mPIhUQE29Yo #}

# BlinkOn 5: Chrome Memory Infra {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="mPIhUQE29Yo"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Primiano Tucci and Petr Cermak talk about memory infrastructure in Chromium.
Slides: https://docs.google.com/presentation/d/1ePz0Xbrxm0pyuDsgJrT-_y_VZqW6Ny4Cs64fvXobQIA/present

This talk was given at BlinkOn 5, a low-key conference for Blink contributors, held on November 10 and November 11, 2015 in Google’s San Francisco office. More details can be found at http://bit.ly/blinkon5
