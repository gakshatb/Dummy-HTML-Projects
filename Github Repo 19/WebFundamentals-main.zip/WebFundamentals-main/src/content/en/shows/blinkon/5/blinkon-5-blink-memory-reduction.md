project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-01-03 #}
{# wf_published_on: 2016-01-03 #}
{# wf_youtube_id: J3V6noKR3s0 #}

# BlinkOn 5: Blink Memory Reduction {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="J3V6noKR3s0"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Kentaro Hara talks about the ongoing work to reduce the memory used by Blink.
Slides: https://docs.google.com/presentation/d/1_LRxXp30j60npShHSRVit0B5tLOS4TLiZ68gQ8nFLsM/edit

This talk was given at BlinkOn 5, a low-key conference for Blink contributors, held on November 10 and November 11, 2015 in Google’s San Francisco office. More details can be found at http://bit.ly/blinkon5
