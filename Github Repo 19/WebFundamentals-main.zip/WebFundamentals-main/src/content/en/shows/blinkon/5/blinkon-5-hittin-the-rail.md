project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-01-03 #}
{# wf_published_on: 2016-01-03 #}
{# wf_youtube_id: R_y03oNcFmE #}

# BlinkOn 5: Hittin' the RAIL {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="R_y03oNcFmE"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Kenji Baheux talks about the RAIL performance model in the context of third party content such as analytics and advertisers.
Slides: https://docs.google.com/presentation/d/1sEdUaOf5yyniGElXuol7w86v2D-62wJQ651520lg4qM/edit

This talk was given at BlinkOn 5, a low-key conference for Blink contributors, held on November 10 and November 11, 2015 in Google’s San Francisco office. More details can be found at http://bit.ly/blinkon5
