project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-05-12 #}
{# wf_published_on: 2015-05-12 #}
{# wf_youtube_id: O0xEnPLWKvQ #}

# Blink Moving OWP Security Forward {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="O0xEnPLWKvQ"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>

Joel Weinberger gives an update on improving web security and new policies around delivering new features.

This talk was given at BlinkOn 4, a low-key conference for Blink contributors, held May 13 and 14 2015 in Google’s Sydney office. More details can be found at http://bit.ly/blinkon4onepager
