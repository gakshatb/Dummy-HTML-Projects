project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-01-03 #}
{# wf_published_on: 2016-01-03 #}
{# wf_youtube_id: LKdio393opE #}

# BlinkOn 5: Perf Insights, RAIL & Happiness {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="LKdio393opE"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Nat Duca talks about various topics related to Blink user happiness including RAIL and Traces.
Slides: https://docs.google.com/presentation/d/1bmqmkX40uW1lujP5ZfTIpJuUFiPHsZKaK0ExTGOg5Jc/edit

This talk was given at BlinkOn 5, a low-key conference for Blink contributors, held on November 10 and November 11, 2015 in Google’s San Francisco office. More details can be found at http://bit.ly/blinkon5
