project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Jake is settling into his brand new role of Headphone Destroyer, and Paul is concerned that it's just too hard to get past building Hello World in today's web.

{# wf_updated_on: 2015-05-31 #}
{# wf_published_on: 2015-05-31 #}
{# wf_youtube_id: 3i9WFgMuKHs #}

# 2.2. Build Tools {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="3i9WFgMuKHs"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Jake is settling into his brand new role of Headphone Destroyer, and Paul is concerned that it's just too hard to get past building Hello World in today's web.

