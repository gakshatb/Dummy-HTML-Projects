project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Paul's been booting frameworks, and unfortunately Jake connected his brain to Twitter

{# wf_updated_on: 2018-04-05 #}
{# wf_published_on: 2017-01-17 #}
{# wf_podcast_audio: https://storage.googleapis.com/http-203-podcast/episode-6.mp3 #}
{# wf_podcast_duration: 00:45:42 #}
{# wf_podcast_fileSize: 55572138 #}
{# wf_podcast_subtitle: Paul's been booting frameworks, and unfortunately Jake connected his brain to Twitter. #}
{# wf_featured_image: /web/shows/http203/podcast/images/http203-episode-5-art.jpg #}

# Legs, Wasps, and Eventually Some Web Stuff. {: .page-title }

<img src="/web/shows/http203/podcast/images/http203-episode-5-art.jpg" class="attempt-right">

In this episode:

* [Gradually booting frameworks](https://aerotwist.com/blog/when-everything-is-important-nothing-is/).
* [Jake pipes brain to Twitter](https://twitter.com/jaffathecake/status/814751108975489024).
* How to fight for quality in the face of deadlines.
* What we're planning on doing in 2017, which includes: media, presentation APIs, cancelable fetch, background fetch, & range requests.

<a href="http://feeds.feedburner.com/Http203Podcast">
  <span class="material-icons">rss_feed</span>
  Subscribe
</a>

<audio style="width: 100%" src="https://storage.googleapis.com/http-203-podcast/episode-6.mp3" controls preload="none">



