project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Paul and Jake talk about the importance of progressive rendering on the web. Unfortunately, Jake can’t figure out how to say 'isomorphic'.

{# wf_updated_on: 2015-06-29 #}
{# wf_published_on: 2015-06-29 #}
{# wf_youtube_id: miLnRHNj7nQ #}

# 2.4. Progressive Loading {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="miLnRHNj7nQ"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Paul and Jake talk about the importance of progressive rendering on the web. Unfortunately, Jake can’t figure out how to say “isomorphic”.

