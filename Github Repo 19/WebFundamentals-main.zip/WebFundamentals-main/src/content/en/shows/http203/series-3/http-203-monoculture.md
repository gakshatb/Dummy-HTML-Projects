project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Paul and Jake are back! This time they're talking about the benefit of multiple browser engines and the power it gives developers.

{# wf_updated_on: 2015-09-07 #}
{# wf_published_on: 2015-09-07 #}
{# wf_youtube_id: IskiTVqHp18 #}

# 3.1. Monoculture {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="IskiTVqHp18"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Paul and Jake are back! This time they're talking about the benefit of multiple browser engines and the power it gives developers.

Make sure you subscribe to our feed below.
