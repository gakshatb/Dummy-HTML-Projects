project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: WebRTC again, and about:blank weirdness.

{# wf_updated_on: 2018-04-05 #}
{# wf_published_on: 2017-12-08 #}
{# wf_podcast_audio: https://storage.googleapis.com/http-203-podcast/episode-12.mp3 #}
{# wf_podcast_duration: 00:16:43 #}
{# wf_podcast_fileSize: 16481061 #}
{# wf_podcast_subtitle: WebRTC again, and about:blank weirdness. #}
{# wf_featured_image: /web/shows/http203/podcast/images/surma-and-jake-2.jpg #}
{# wf_blink_components: Blink>WebRTC, Blink>DOM #}

# WebRTC again, and about:blank weirdness {: .page-title }

<img src="/web/shows/http203/podcast/images/surma-and-jake-2.jpg" class="attempt-right">

In this mini-episode:

* WebRTC again – some folks weren't happy with our last episode, so we try to clarify things.
* [Comlink over WebRTC](https://dassur.ma/things/comlink-webrtc/).
* [Easy RTC](https://easyrtc.com/).
* The British positivity index.
* [about:blank is weird](https://hsivonen.fi/about-blank/).
* [Unusual iframe global behaviour](https://twitter.com/jaffathecake/status/923219775328849921).
* Should web APIs try to hide complexity, or present things as they are?

<a href="http://feeds.feedburner.com/Http203Podcast">
  <span class="material-icons">rss_feed</span>
  Subscribe
</a>

<audio style="width: 100%" src="https://storage.googleapis.com/http-203-podcast/episode-12.mp3" controls preload="none">
