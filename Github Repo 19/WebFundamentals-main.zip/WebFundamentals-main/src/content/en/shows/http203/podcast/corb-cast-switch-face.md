project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Also spices, screen-touchers, and lasers.

{# wf_updated_on: 2018-08-08 #}
{# wf_published_on: 2018-08-08 #}
{# wf_podcast_audio: https://storage.googleapis.com/http-203-podcast/episode-17.mp3 #}
{# wf_podcast_duration: 00:33:06 #}
{# wf_podcast_fileSize: 20954289 #}
{# wf_podcast_subtitle: Also spices, screen-touchers, and lasers. #}
{# wf_featured_image: /web/shows/http203/podcast/images/jake-in-pain.jpg #}
{# wf_blink_components: Blink>Messaging, Blink>SecurityFeature #}

# CORB, BroadcastChannel, and the resting Switch face {: .page-title }

<img src="/web/shows/http203/podcast/images/jake-in-pain.jpg" class="attempt-right">

In this episode:

* [Eyes and lasers](https://twitter.com/Foone/status/1014267515696922624).
* Jake's resting Switch face.
* People who *touch your monitor with their filthy fingers*.
* Eating the world's hottest chilli.
* [Jake's euroramen](https://twitter.com/jaffathecake/status/963287863268904964).
* [Cross origin read
  blocking](https://chromium.googlesource.com/chromium/src/+/master/services/network/cross_origin_read_blocking_explainer.md).
* [Site isolation](/web/updates/2018/07/site-isolation).
* [OOPIFs](https://www.chromium.org/developers/design-documents/oop-iframes).
* The [no-sniff
  header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Content-Type-Options).
* [BroadcastChannel](https://developer.mozilla.org/en-US/docs/Web/API/Broadcast_Channel_API).
* The [localStorage change
  event](https://developer.mozilla.org/en-US/docs/Web/API/WindowEventHandlers/onstorage).
* Can Surma even speak German?

<a href="http://feeds.feedburner.com/Http203Podcast">
  <span class="material-icons">rss_feed</span>
  Subscribe
</a>

<audio style="width: 100%" src="https://storage.googleapis.com/http-203-podcast/episode-17.mp3"
controls preload="none"></audio>
