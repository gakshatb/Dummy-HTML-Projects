project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Also zombie optimizations and alphabets

{# wf_updated_on: 2018-11-29 #}
{# wf_published_on: 2018-11-08 #}
{# wf_podcast_audio: https://storage.googleapis.com/http-203-podcast/episode-19.mp3 #}
{# wf_podcast_duration: 00:56:31 #}
{# wf_podcast_fileSize: 34864351 #}
{# wf_podcast_subtitle: Also zombie optimizations and alphabets #}
{# wf_featured_image: /web/shows/http203/podcast/images/surma-and-jake-2.jpg #}
{# wf_blink_components: Blink>Canvas, Blink>Workers #}

# Stress, canvas, and jam {: .page-title }

<img src="/web/shows/http203/podcast/images/surma-and-jake-2.jpg" class="attempt-right">

In this episode:

* Jake and Surma stress about Chrome Dev Summit.
* Surma fails to go to America.
* [Offscreen canvas](/web/updates/2018/08/offscreen-canvas).
* [Low latency canvas](https://www.chromestatus.com/feature/6360971442388992).
* Buzzword of the month: Jam stack.
* "When is it good to not be jam".
* A man left £2 on a train.
* Radio alphabets.
* And also radio alphabets.

<a href="http://feeds.feedburner.com/Http203Podcast">
  <span class="material-icons">rss_feed</span>
  Subscribe
</a>

<audio style="width: 100%" src="https://storage.googleapis.com/http-203-podcast/episode-19.mp3"
controls preload="none"></audio>
