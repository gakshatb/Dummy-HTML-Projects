project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Paul and Jake discuss maintainable and reusable code, and a fun way to remember the command line parameters for untaring a file.

{# wf_updated_on: 2015-09-21 #}
{# wf_published_on: 2015-09-21 #}
{# wf_youtube_id: Pvm3k4gpH0A #}

# 3.2. Maintainable Code {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Pvm3k4gpH0A"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Paul and Jake discuss maintainable and reusable code, and a fun way to remember the command line parameters for untaring a file.

Make sure you subscribe to our feed below.
