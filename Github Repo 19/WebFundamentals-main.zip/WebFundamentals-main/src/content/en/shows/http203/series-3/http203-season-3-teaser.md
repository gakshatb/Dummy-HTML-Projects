project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: HTTP 203 returns September the 8th! The new season chronicles the daft duo's trip to Google I/O 2015. They sample various aspects of the US, get sunburnt, and even find time to talk about the web.

{# wf_updated_on: 2015-05-17 #}
{# wf_published_on: 2015-05-17 #}
{# wf_youtube_id: cOPhSJ6SUrg #}

# Season 3 Teaser {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="cOPhSJ6SUrg"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


HTTP 203 returns September the 8th! The new season chronicles the daft duo's trip to Google I/O 2015. They sample various aspects of the US, get sunburnt, and even find time to talk about the web.
