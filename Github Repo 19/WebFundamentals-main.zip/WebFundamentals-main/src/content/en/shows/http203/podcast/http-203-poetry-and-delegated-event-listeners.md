project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Jake brings his A+ poetry game, and Paul muses over the performance implications of event delegation.

{# wf_updated_on: 2018-04-05 #}
{# wf_published_on: 2015-10-24 #}
{# wf_podcast_audio: https://storage.googleapis.com/http-203-podcast/episode-3.mp3 #}
{# wf_podcast_duration: 00:32:30 #}
{# wf_podcast_fileSize: 29840530 #}
{# wf_podcast_subtitle: Paul and Jake talk about poetry, event listeners, and content that jumps around your screen. #}
{# wf_featured_image: /web/shows/http203/podcast/images/http203-episode-3-art.jpg #}

# Poetry and Delegated Event Listeners {: .page-title }

Jake brings his A+ poetry game, and Paul muses over the performance implications of event delegation.

<img src="/web/shows/http203/podcast/images/http203-episode-3-art.jpg" class="attempt-right">

In this episode:

 * Fingers in pockets
 * Poetry
 * Content that jumps
 * Surveys
 * Event delegation
 * Insecure content in Chrome

<a href="http://feeds.feedburner.com/Http203Podcast">
  <span class="material-icons">rss_feed</span>
  Subscribe
</a>

<audio style="width: 100%" src="https://storage.googleapis.com/http-203-podcast/episode-3.mp3" controls preload="none">
