project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: HTTP 203 - Where do we start. Jake and Surma talk about web development. Or they are supposed to. No topic seems to be off-topic.

{# wf_blink_components: N/A #}
{# wf_updated_on: 2019-01-04 #}
{# wf_published_on: 2016-08-24 #}

# HTTP 203 {: .page-title }

<img src="/web/shows/http203/podcast/images/surma-and-jake-2.jpg" class="attempt-right">

**Where do we start?** Jake and Surma talk about web development. Or they are
supposed to. No topic seems to be off-topic.

[YouTube](https://www.youtube.com/playlist?list=PLNYkxOF6rcIAKIQFsNbV0JDws_G_bnNo9)

[Podcast](podcast/)
