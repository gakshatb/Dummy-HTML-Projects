project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: HTTP 203 Season 2 is coming 5/18! Paul and Jake are back talking about the Web. Well sort of... if you listen closely you’ll hear a rustle… a Kurt Russell…

{# wf_updated_on: 2015-05-17 #}
{# wf_published_on: 2015-05-17 #}
{# wf_youtube_id: kC5MmY54IBE #}

# Season 2 Teaser {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="kC5MmY54IBE"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


HTTP 203 Season 2 is coming 5/18! Paul and Jake are back talking about the Web. Well sort of... if you listen closely you’ll hear a rustle… a Kurt Russell…

Make sure you subscribe to our feed below.
