project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: From talking vDOM to lying to users, Paul & Jake are all about ensuring users get blazing fast sites.

{# wf_updated_on: 2015-07-12 #}
{# wf_published_on: 2015-07-12 #}
{# wf_youtube_id: 6Zgp_G5o6Oc #}

# 2.5. Performance Matters {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="6Zgp_G5o6Oc"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


From talking vDOM to lying to users, Paul & Jake are all about ensuring users get blazing fast sites.

Make sure you subscribe to our feed below.
