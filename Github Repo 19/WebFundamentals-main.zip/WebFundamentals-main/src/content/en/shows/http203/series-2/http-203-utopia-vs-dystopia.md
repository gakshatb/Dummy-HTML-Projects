project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: What does the future hold for the web? Paul and Jake discuss utopian and dystopian options... and it turns out Paul hates Blade Runner, although he may be confusing it with Highlander.

{# wf_updated_on: 2015-07-26 #}
{# wf_published_on: 2015-07-26 #}
{# wf_youtube_id: Hy6wceqkxvA #}

# 2.6. Utopia vs. Dystopia {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Hy6wceqkxvA"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


What does the future hold for the web? Paul and Jake discuss utopian and dystopian options... and it turns out Paul hates Blade Runner, although he may be confusing it with Highlander.

