project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Jake is worse at quizzes than Paul.

{# wf_updated_on: 2018-04-05 #}
{# wf_published_on: 2017-03-01 #}
{# wf_podcast_audio: https://storage.googleapis.com/http-203-podcast/episode-7.mp3 #}
{# wf_podcast_duration: 00:47:39 #}
{# wf_podcast_fileSize: 68450844 #}
{# wf_podcast_subtitle: Jake is worse at quizzes than Paul. #}
{# wf_featured_image: /web/shows/http203/podcast/images/http203-episode-5-art.jpg #}

# Quizzing, animating, and canceling {: .page-title }

<img src="/web/shows/http203/podcast/images/http203-episode-5-art.jpg" class="attempt-right">

In this episode:

* Jake is bad at quizzes.
* [NodeIterator](https://developer.mozilla.org/en-US/docs/Web/API/NodeIterator) and [TreeWalker](https://developer.mozilla.org/en-US/docs/Web/API/TreeWalker).
* New, exciting stuff in Safari.
* [Firefox `<select>`](https://hg.mozilla.org/mozilla-central/rev/544ad41d3dcf9059a70aeae55a9dcce031f22b1c).
* Animating height with performance.
* [Fetch canceling](https://github.com/whatwg/fetch/issues/447#issuecomment-281731850).

<a href="http://feeds.feedburner.com/Http203Podcast">
  <span class="material-icons">rss_feed</span>
  Subscribe
</a>

<audio style="width: 100%" src="https://storage.googleapis.com/http-203-podcast/episode-7.mp3" controls preload="none">



