project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: This week, Paul & Jake talk about the future of JavaScript: ES6 and beyond.

{# wf_updated_on: 2015-10-05 #}
{# wf_published_on: 2015-10-05 #}
{# wf_youtube_id: pLLLf1QPgoU #}

# 3.3. The Future of JavaScript {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="pLLLf1QPgoU"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


This week, Paul & Jake talk about the future of JavaScript: ES6 and beyond.

Make sure you subscribe to our feed below.
