project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Ho ho ho! 2014 has been a great year for the web, and Paul and Jake thought a roundup would be just the ticket for finishing the year in festive style! Don’t miss out on the duo’s web Xmas jokes after the credits!

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: tNgBQC9qMP4 #}

# Christmas Special {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="tNgBQC9qMP4"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Ho ho ho! 2014 has been a great year for the web, and [Paul](https://twitter.com/aerotwist) and [Jake](https://twitter.com/jaffathecake) thought a roundup would be just the ticket for finishing the year in festive style! Don’t miss out on the duo’s web Xmas jokes after the credits!
