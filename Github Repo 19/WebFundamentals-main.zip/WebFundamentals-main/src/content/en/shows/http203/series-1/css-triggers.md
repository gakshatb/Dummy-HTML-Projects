project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: How do you know if a CSS property is going to cause you performance problems? Looks like Paul has an answer he's desperate to tell Jake.

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: mdcA5fR91S8 #}

# 1. CSS Triggers {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="mdcA5fR91S8"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


How do you know if a CSS property is going to cause you performance problems? Looks like [Paul](https://twitter.com/aerotwist) has an answer he's desperate to tell [Jake](https://twitter.com/jaffathecake).

Don't miss Jake's bizarre revelation about keyboard design!

## Read more

* [CSS Triggers](http://csstriggers.com)
