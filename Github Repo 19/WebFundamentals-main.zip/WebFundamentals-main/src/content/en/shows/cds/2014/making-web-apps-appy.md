project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: QbuLq4f6DGQ #}

# Making Web Apps Appy {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="QbuLq4f6DGQ"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Alex gives an overview of why web apps don’t feel “appy” today, and shows how service worker is enabling a whole new world of appiness - beyond the simple goal of making web apps work offline, to building truly engaging web applications.
