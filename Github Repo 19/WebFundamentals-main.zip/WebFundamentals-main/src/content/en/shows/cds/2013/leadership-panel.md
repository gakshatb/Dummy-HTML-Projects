project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Chrome Leadership Q&A with Ian Ellison-Taylor, Darin Fisher, Linus Upson, Erik Kay, Arnaud Weber, Hiroshi Lockheimer

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: 6FnC6Fdn8vc #}

# Chrome Leadership Panel Q&A {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="6FnC6Fdn8vc"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Chrome Leadership Q&A with Ian Ellison-Taylor, Darin Fisher, Linus Upson, Erik Kay, Arnaud Weber, Hiroshi Lockheimer
