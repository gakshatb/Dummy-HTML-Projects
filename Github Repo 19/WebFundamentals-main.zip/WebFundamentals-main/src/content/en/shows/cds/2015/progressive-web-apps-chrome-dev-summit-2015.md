project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-11-17 #}
{# wf_published_on: 2015-11-17 #}
{# wf_youtube_id: MyQ8mtR9WxI #}

# Progressive Web Apps (Chrome Dev Summit 2015) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="MyQ8mtR9WxI"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Progressive Web Apps are fast, robust, app-like experiences built using service workers and other modern web capabilities. Join Alex Russell and Andreas Bovens to get a deep understanding of how to build these modern web experiences.

Watch more talks from Chrome Dev Summit 2015: https://goo.gl/e4c7vD

Subscribe to the Chrome Developers channel at: https://goo.gl/OUF4e2
