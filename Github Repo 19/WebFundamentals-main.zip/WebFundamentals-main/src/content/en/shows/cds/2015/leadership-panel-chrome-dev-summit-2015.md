project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-11-18 #}
{# wf_published_on: 2015-11-18 #}
{# wf_youtube_id: RYAU4i2rqm0 #}

# Leadership Panel (Chrome Dev Summit 2015) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="RYAU4i2rqm0"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Watch our panel of specialists answer questions about Chrome and the future of the web platform. Our panelists: Greg Simon, Engineering director, Darin Fisher, VP, Engineering, Grace Kloba, principal on Chrome mobile, Rahul Roy-Chowdhury, director of product management, Dimitri Glazkov, software engineer, Alex Komoroske, senior project manager, Matt McNulty, software engineer, and Parisa Tabriz, security princess (that's her real title).


Watch more talks from Chrome Dev Summit 2015: https://goo.gl/e4c7vD

Subscribe to the Chrome Developers channel at: https://goo.gl/OUF4e2
