project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2017-07-25 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: 6vcQlD-jadk #}

# Easy Composition and Reuse with Web Components {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="6vcQlD-jadk"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Dimitri explores the set of enabling technologies that make up Web Components, and describes how these pieces make it easy and fast to build composable components, and make HTML finally earn its keep.
