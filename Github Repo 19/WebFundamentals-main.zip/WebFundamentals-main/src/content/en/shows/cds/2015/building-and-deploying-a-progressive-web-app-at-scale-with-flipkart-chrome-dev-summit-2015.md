project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-11-18 #}
{# wf_published_on: 2015-11-18 #}
{# wf_youtube_id: StdKz32M1RM #}

# Building and deploying a Progressive Web App at scale with Flipkart (Chrome Dev Summit 2015) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="StdKz32M1RM"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Flipkart is one of the largest e-commerce companies in India. Hear from their development team about their approach in architecting an immersive mobile experience that is fast, reliable and engaging.

Watch more talks from Chrome Dev Summit 2015: https://goo.gl/e4c7vD

Subscribe to the Chrome Developers channel at: https://goo.gl/OUF4e2
