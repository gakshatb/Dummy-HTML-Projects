project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-11-16 #}
{# wf_published_on: 2015-11-16 #}
{# wf_youtube_id: m2a9hlUFRhg #}

# Keynote by Darin Fisher, VP of Chrome (Chrome Dev Summit 2015) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="m2a9hlUFRhg"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Join Darin Fisher, VP of Chrome as he talks the past, present and future of the web.

Watch more talks from Chrome Dev Summit 2015: https://goo.gl/e4c7vD

Subscribe to the Chrome Developers channel at: https://goo.gl/OUF4e2
