project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: v0xRTEf-ytE #}

# Wicked Fast (Performance Investment) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="v0xRTEf-ytE"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Ryan gives an overview of some of the architectural improvements we've been making to Chrome to ensure that it's easy to make 60fps web applications across any device, as well as some features that help your apps perform silky-smooth.
