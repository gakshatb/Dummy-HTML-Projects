project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Paul Irish covers the new Chrome DevTools for mobile development at the Chrome Dev Summit, November 20, 2013. In 23 minutes, learn about zero-config remote debugging, screencasting device screen to desktop, and near-perfect mobile emulation.

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: gZH1d2Co1X0 #}

# DevTools for Mobile {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="gZH1d2Co1X0"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Paul Irish covers the new Chrome DevTools for mobile development at the Chrome Dev Summit, November 20, 2013.
In 23 minutes, learn about zero-config remote debugging, screencasting device screen to desktop, and near-perfect mobile emulation.

## Read More

- [Chrome DevTools for Mobile](http://www.html5rocks.com/en/tutorials/developertools/mobile/){: .external }
