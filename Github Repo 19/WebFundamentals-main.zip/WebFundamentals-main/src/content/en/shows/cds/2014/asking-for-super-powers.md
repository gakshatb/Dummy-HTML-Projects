project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2017-07-25 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: 3dAwZVsS8wo #}

# Asking for Superpowers: Chrome's Permission Model {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="3dAwZVsS8wo"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Adrienne explains how we can enable more powerful web applications while keeping a user focus on security and privacy, and how you should structure your own apps to take best advantage.
