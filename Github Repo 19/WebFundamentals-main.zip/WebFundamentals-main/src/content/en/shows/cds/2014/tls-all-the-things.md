project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: ayD0LiZkWLQ #}

# TLS All the Things! Security with Performance {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="ayD0LiZkWLQ"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


TLS underlies all security and privacy on the web. Chris explains how to do TLS right: not only to deploy TLS and remain performant at scale, but also demonstrating how TLS is the basis of new performance improvements.
