project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: lboyR-A1woU #}

# Keynote {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="lboyR-A1woU"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Darin Fisher introduces the Chrome Developer Summit. This year the Summit presentation mainly focuses on performance, Polymer, Material Design, and building mobile web apps that work like apps with service worker and other technologies. but also features breakouts and panels to discuss what you want to discuss.
