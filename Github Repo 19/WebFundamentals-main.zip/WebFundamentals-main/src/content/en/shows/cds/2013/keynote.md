project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml
description: Chrome Dev Summit keynote by Linus Upson—VP of Engineering for Chrome.

{# wf_updated_on: 2015-02-23 #}
{# wf_published_on: 2015-02-23 #}
{# wf_youtube_id: 20fGtfnxJuo #}

# Keynote {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="20fGtfnxJuo"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Chrome Dev Summit keynote by Linus Upson—VP of Engineering for Chrome.
