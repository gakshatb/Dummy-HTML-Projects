project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-11-17 #}
{# wf_published_on: 2015-11-17 #}
{# wf_youtube_id: w0O2znkSBXA #}

# Owning your performance: RAIL (Chrome Dev Summit 2015) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="w0O2znkSBXA"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Join Paul Irish in a deep-dive of a site and how you can use Chrome DevTools to apply the principles of RAIL to diagnose and fix your site.

Paul Irish is a front-end developer who loves the web. He works on Google Chrome, its performance and DevTools.

Watch more talks from Chrome Dev Summit 2015: https://goo.gl/e4c7vD

Subscribe to the Chrome Developers channel at: https://goo.gl/OUF4e2
