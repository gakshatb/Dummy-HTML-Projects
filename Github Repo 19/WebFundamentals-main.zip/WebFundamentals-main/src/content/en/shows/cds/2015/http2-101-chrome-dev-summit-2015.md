project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2015-11-18 #}
{# wf_published_on: 2015-11-18 #}
{# wf_youtube_id: r5oT_2ndjms #}

# HTTP/2 101 (Chrome Dev Summit 2015) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="r5oT_2ndjms"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


HTTP/2 is coming. Actually, it’s here. Right now. It impacts not only your user’s experience but also the way you need to think about your website and web apps. Let’s see how HTTP/2 came to be and how it makes development easier.

Surma is an engineer working with the Chrome team. He likes to cut himself on the bleeding edge, goes full-stack every once in a while and prefers good code over functional one.

Watch more talks from Chrome Dev Summit 2015: https://goo.gl/e4c7vD

Subscribe to the Chrome Developers channel at: https://goo.gl/OUF4e2
