project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-08 #}
{# wf_published_on: 2016-06-08 #}
{# wf_youtube_id: hyhNcVH4efs #}

# PWA Developer Summit 2016 is coming! {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="hyhNcVH4efs"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Register here https://goo.gl/pcPTTv for the Progressive Web App Dev Summit 2016 in Amsterdam on June 20th and 21st! 

Check out the live stream here https://goo.gl/Fu2rxs at 10am June 20th!

Learn how to build great web experiences that load quickly and are amazing to use in every browser and how to weave in the latest platform technologies to deliver a great Progressive Web App. Digging into Service Workers, add to Home Screen, Push Notifications,  building Fast, Responsive and Secure experiences.

Register today and join Rob Dodson and many other Google Chrome Developers in Amsterdam!
