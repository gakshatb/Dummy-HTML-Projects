project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2019-06-08 #}
{# wf_published_on: 2016-06-19 #}
{# wf_youtube_id: 1qqZIeQNuxE #}
{# wf_blink_components: N/A #}

# Summit Report: Making Progressive Web Apps accessible, at scale! (Progressive Web App Summit 2016) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="1qqZIeQNuxE"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Paul Lewis sits down with Rob "BobDod" Dodson to discuss accessibility and Progressive Web Apps, the subject of his latest Udacity course.

Web Accessibility Udacity course: bit.ly/web-a11y
WCAG 2.0: https://www.w3.org/TR/WCAG20/
Web AIM Checklist: https://webaim.org/standards/wcag/checklist

Watch Rob’s Progressive Web App Summit 2016 talk here https://goo.gl/EiGexu

[Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel

Music by Terra Monk: https://soundcloud.com/terramonk/pwa-amsterdam-2016
