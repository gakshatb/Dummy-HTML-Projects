project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-19 #}
{# wf_published_on: 2016-06-19 #}
{# wf_youtube_id: TVolBgyaiTQ #}

# Summit Report: Checking in with Paul Lewis and Jake Archibald (Progressive Web Apps Summit 2016) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="TVolBgyaiTQ"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Instant loading and the uncanny valley. Rob catches up with Jake and Paul to discuss the benefits of building offline first experiences.

To learn more about streams check out Jake's post: 2016 - The Year of Web Streams
https://goo.gl/FPCCah

Watch Paul’s Progressive Web App Summit 2016 talk here https://goo.gl/jvv0M4 and Jake’s here https://goo.gl/BFpaeG

[Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel and tune into our playlist to catch all the talks from the summit
https://www.youtube.com/playlist?list=PLNYkxOF6rcIAWWNR_Q6eLPhsyx6VvYjVb

Music by Terra Monk: https://soundcloud.com/terramonk/pwa-amsterdam-2016
