project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-19 #}
{# wf_published_on: 2016-06-19 #}
{# wf_youtube_id: 9Jef9IluQw0 #}

# Opening Keynote (Progressive Web App Summit 2016) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="9Jef9IluQw0"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


It's now possible to build fast, engaging, reliable mobile web experiences that are great for users and good for businesses. We'll kick off the two day summit with an overview of Progressive Web Apps as well as strategies for how you can integrate these new technologies into your own site.

[Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel

Music by Terra Monk: https://soundcloud.com/terramonk/pwa-amsterdam-2016
