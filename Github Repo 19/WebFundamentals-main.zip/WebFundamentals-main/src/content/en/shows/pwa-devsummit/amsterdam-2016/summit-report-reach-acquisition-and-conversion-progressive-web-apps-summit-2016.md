project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-19 #}
{# wf_published_on: 2016-06-19 #}
{# wf_youtube_id: Vou8NruMyWA #}

# Summit Report: Reach, acquisition and conversion (Progressive Web Apps Summit 2016) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Vou8NruMyWA"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Rob sits down with Thao Tran from the Chrome team to hear about the benefits Progressive Web Apps offer to companies looking to grow their userbase quickly.

For PWA Case Studies see: https://goo.gl/aEJ7Yc

Watch Thao’s Progressive Web App Summit 2016 talk here https://goo.gl/F3qdsg

[Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel and tune into our playlist to catch all the talks from the summit
https://www.youtube.com/playlist?list=PLNYkxOF6rcIAWWNR_Q6eLPhsyx6VvYjVb

Music by Terra Monk: https://soundcloud.com/terramonk/pwa-amsterdam-2016
