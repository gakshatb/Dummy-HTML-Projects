project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-19 #}
{# wf_published_on: 2016-06-19 #}
{# wf_youtube_id: zHNYFUhVzgw #}

# Putting the Progressive in Progressive Web Apps (Progressive Web App Summit 2016) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="zHNYFUhVzgw"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Progressive Web Apps should work everywhere for every user. But what happens when the technology and API's are not available for in your users browser? In this talk we will show you how you can think about and build sites that work everywhere.

[Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel

Music by Terra Monk: https://soundcloud.com/terramonk/pwa-amsterdam-2016
