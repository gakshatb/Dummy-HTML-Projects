project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-19 #}
{# wf_published_on: 2016-06-19 #}
{# wf_youtube_id: oKQpfevHHUY #}

# Summit Report: Progressive Web Apps for any occassion! (Progressive Web App Summit 2016) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="oKQpfevHHUY"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Rob sits down with Dion Almaer to chat Progressive Web Apps and "buzzword fatigue", and why big businesses would be interested in building PWAs.

Learn more about Progressive Web App fundamentals at developers.google.com/web

[Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel and tune into our playlist to catch all the talks from the summit
https://www.youtube.com/playlist?list=PLNYkxOF6rcIAWWNR_Q6eLPhsyx6VvYjVb

Music by Terra Monk: https://soundcloud.com/terramonk/pwa-amsterdam-2016
