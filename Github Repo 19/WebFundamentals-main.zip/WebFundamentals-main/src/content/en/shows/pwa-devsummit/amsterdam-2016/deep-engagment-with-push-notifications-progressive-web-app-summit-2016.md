project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-19 #}
{# wf_published_on: 2016-06-19 #}
{# wf_youtube_id: Zq-tRtBN3ws #}

# Deep Engagment with Push Notifications (Progressive Web App Summit 2016) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="Zq-tRtBN3ws"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Push notifications are an incredibly effective way to build deeper user engagement with your application, and are now available on the web. In this session, we'll take a look at how they work and deep-dive into how to implement push notifications in web applications, from beginning to end

[Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel

Music by Terra Monk: https://soundcloud.com/terramonk/pwa-amsterdam-2016
