project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-19 #}
{# wf_published_on: 2016-06-19 #}
{# wf_youtube_id: KNhawR8fGAM #}

# PWA Dev Summit 2016 - Day 1 Live Stream! {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="KNhawR8fGAM"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


The Progressive Web App Summit 2016 is here! You can view the Day 1 live stream right now: https://goo.gl/Fu2rxs

Watch talks and learn how you can build great web experiences that load quickly and work amazingly well in every browser. You can also learn how to weave in the latest platform technologies to deliver great Progressive Web Apps. Join Paul Lewis, Thao Tran, Jake Archibald and many more!

Don't miss Day 2 live stream here: https://goo.gl/EWlmfh
