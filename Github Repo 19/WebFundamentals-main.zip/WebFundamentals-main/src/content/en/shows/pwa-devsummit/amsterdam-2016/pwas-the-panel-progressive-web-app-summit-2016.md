project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-20 #}
{# wf_published_on: 2016-06-20 #}
{# wf_youtube_id: EyyEfxrk_NU #}

# PWAs: The Panel (Progressive Web App Summit 2016) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="EyyEfxrk_NU"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


A collection of browser vendors and experts across the Progressive Web App platform discuss issues and their visions for the future. Moderated by Jeremy Keith

Music by Terra Monk: https://soundcloud.com/terramonk/pwa-amsterdam-2016

[Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel
