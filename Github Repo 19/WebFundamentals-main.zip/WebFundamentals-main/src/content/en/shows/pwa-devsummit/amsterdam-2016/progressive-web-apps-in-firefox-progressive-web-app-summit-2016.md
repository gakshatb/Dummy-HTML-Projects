project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-20 #}
{# wf_published_on: 2016-06-20 #}
{# wf_youtube_id: DrO8c4KIqg0 #}

# Progressive Web Apps in Firefox (Progressive Web App Summit 2016) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="DrO8c4KIqg0"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Join Ben Kelly as he discusses the efforts and initiatives that Mozilla is working on with Progressive Web Apps.

Ben Kelly is a software engineer on Mozilla's platform team. His main focus has been helping to implement and support service workers in Firefox.

Music by Terra Monk: https://soundcloud.com/terramonk/pwa-amsterdam-2016

[Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel
