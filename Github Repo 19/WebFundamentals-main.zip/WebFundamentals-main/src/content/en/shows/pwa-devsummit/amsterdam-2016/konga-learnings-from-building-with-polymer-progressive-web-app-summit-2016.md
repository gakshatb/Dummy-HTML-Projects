project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-20 #}
{# wf_published_on: 2016-06-20 #}
{# wf_youtube_id: GNbVdPi24gg #}

# Konga: Learnings from Building with Polymer (Progressive Web App Summit 2016) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="GNbVdPi24gg"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Konga is a leading e-commerce website in Nigeria, selling everything from books to fridges to mobile phones. Mobile devices provide the largest source of traffic and user growth. 

The Konga team explain how they built a PWA with Polymer to accommodate user needs for this market and its specifics.

Music by Terra Monk: https://soundcloud.com/terramonk/pwa-amsterdam-2016

[Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel
