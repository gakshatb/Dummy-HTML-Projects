project_path: /web/_project.yaml
book_path: /web/shows/_book.yaml

{# wf_updated_on: 2016-06-19 #}
{# wf_published_on: 2016-06-19 #}
{# wf_youtube_id: kxE4bLSC-xw #}

# Summit Report: Building for billions with Progressive Web Apps (Progressive Web App Summit 2016) {: .page-title }


<div class="video-wrapper">
  <iframe class="devsite-embedded-youtube-video" data-video-id="kxE4bLSC-xw"
          data-autohide="1" data-showinfo="0" frameborder="0" allowfullscreen>
  </iframe>
</div>


Rob talks connectivity, context and optimization with Tal Oppenheimer, who's building Progressive Web Apps for the next billion users.

Learn more about building for billions: https://goo.gl/kTTRVo

Watch Tal's Progressive Web App Summit 2016 talk here https://goo.gl/CYM34j

[Subscribe](https://goo.gl/LLLNvf) to the Google Developers Channel
