# Web Fundamentals on DevSite

**This repo has been archived and is not accepting any new issues or pull requests.**

All of the content from [developers.google.com/web/][dgc] has been moved to
[web.dev](https://web.dev) or [developer.chrome.com](https://developer.chrome.com).

The source for [developers.google.com/web/][dgc] is now in `google3`. Changes
made here will not be published on DevSite.

[dgc]: https://developers.google.com/web/
