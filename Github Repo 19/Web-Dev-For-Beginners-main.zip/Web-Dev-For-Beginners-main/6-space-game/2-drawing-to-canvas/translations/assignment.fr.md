# Jouer avec l'API Canvas

## Instructions

Choisissez un élément de l'API Canvas et créez quelque chose d'intéressant autour de lui. Pouvez-vous créer une petite galaxie d'étoiles répétées ? Pouvez-vous créer une texture intéressante de lignes colorées ? Vous pouvez vous inspirer de CodePen (mais ne copiez pas).

## Rubrique

| Critères | Exemplaire                                                 | Adéquat                            | Besoin d'amélioration     |
| -------- | --------------------------------------------------------- | ----------------------------------- | --------------------- |
|          | Le code est soumis montrant une texture ou une forme intéressante | Le code est soumis, mais ne s'exécute pas | Le code n'est pas soumis |