# Menganalisis laman web untuk prestasi

Berikan laporan terperinci dari laman web, menunjukkan kawasan di mana prestasi bermasalah. Analisis mengapa laman web ini perlahan dan apa yang anda boleh lakukan untuk mempercepatnya. Jangan hanya bergantung pada alat penyemak imbas, tetapi lakukan kajian mengenai alat lain yang dapat membantu laporan anda.

## Rubrik

| Kriteria | Contoh                                                                                                  | Mencukupi                    | Usaha Lagi             |
| -------- | ---------------------------------------------------------------------------------------------------------- | --------------------------- | ----------------------------- |
|          | Laporan disajikan dengan perincian yang diambil bukan hanya dari alat penyemak imbas tetapi dari alat pihak ketiga jika ada | Laporan asas dibentangkan | Laporan minimum dibentangkan |
