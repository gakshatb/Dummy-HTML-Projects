# Restyling dell'estensione

## Istruzioni

Il base di odice per questa estensione è completa di stili, ma non è necessario utilizzarli; personalizzare la propria estensione modificandone il file css.

## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | -------------------------------------------- | --------------------- | ----------------- |
|          | Il codice viene presentato con nuovi stili funzionali | Lo stile è incompleto | Gli stili sono difettosi |