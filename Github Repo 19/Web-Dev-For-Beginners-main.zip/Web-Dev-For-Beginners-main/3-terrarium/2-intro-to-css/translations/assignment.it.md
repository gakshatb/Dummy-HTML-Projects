# Rifattorizzare CSS

## Istruzioni

Restyling del terrario utilizzando Flexbox o CSS Grid, acquisire schermate per mostrare che lo si è testato su diversi browser. Potrebbe essere necessario modificare il markup, quindi creare una nuova versione dell'app con la grafica disposta per il refactoring. Non ci si preoccupi di rendere gli elementi trascinabili; per ora rifattorizzare solo HTML e CSS.

## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | ----------------------------------------------------------------- | ----------------------------- | ------------------------------------ |
|          | Presenta un terrario completamente rinnovato utilizzando Flexbox o CSS Grid | Restyling di alcuni elementi | Il restyling del terrario è completamente fallito |
