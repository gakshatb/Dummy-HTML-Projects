# Travailler un peu plus avec le DOM

## Instructions

Recherchez un peu plus sur le DOM en 'adoptant' un élément du DOM. Visitez la [liste des interfaces DOM de MDN ](https://developer.mozilla.org/fr/docs/Web/API/Document_Object_Model) et choisissez-en une. Trouvez une de ces utilisations dans un site sur le web et rédigez une explication sur la façon dont elle est utilisée.

## Rubrique

| Critères | Exemplaire                                     | Adéquat                                         | Besoin d'amélioration       |
| -------- | --------------------------------------------- | ------------------------------------------------ | ----------------------- |
|          | La rédaction du paragraphe est présentée, avec un exemple | La rédaction du paragraphe est présentée, sans exemple | Aucune rédaction n'est présentée |
