# Pratique seu HTML: Construa um mockup de blog

## Instruções

Imagine que você está projetando ou redesenhando seu web site pessoal. Crie um mockup gráfico do seu site e então escreva as marcações HTML que você usaria para construir os vários elementos do site. Você pode fazer isso no papel e digitalizar ou usar o software de sua preferência, apenas tenha certeza de elaborar manualmente a marcação HTML.

## Rubrica

| Critério | Exemplar                                                                           | Adequado                                                                         | Precisa de melhoria                                                                 |
| -------- | ----------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- |
|          | Um layout de blog é representado visualmente com pelo menos 10 elementos de marcação HTML exibidos | Um layout de blog é representado visualmente com cerca de 5 elementos de marcação HTML exibidos | Um layout de blog é representado com no máxiom 3 elementos de marcação HTML exibidos |