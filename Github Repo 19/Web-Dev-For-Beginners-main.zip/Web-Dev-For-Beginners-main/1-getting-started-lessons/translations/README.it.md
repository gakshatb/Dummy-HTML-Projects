# Iniziare con lo Sviluppo Web

In questa sezione del curriculum, vi saranno introdotti concetti non relativi al progetto importanti per diventare uno sviluppatore professionista.

### Argomenti

1. [Introduzione ai Linguaggi di Programmazione e agli Strumenti Necessari](../1-intro-to-programming-languages/translations/README.it.md)
2. [Concetti base di GitHub](../2-github-basics/translations/README.it.md)
3. [Concetti base di Accessibilità](../3-accessibility/translations/README.it.md)

### Riconoscimenti

Concetti Base di Accessibilità è stato scritto con il ♥️ da [Christopher Harrison](https://twitter.com/geektrainer)

Introduzione a GitHub è stato scritto con il ♥️ da [Floor Drees](https://twitter.com/floordrees)

Introduzione ai Linguaggi di Programmazione e agli Strumenti Necessari sono stati scritti con il  ♥️ da [Jasmine Greenaway](https://twitter.com/paladique)
