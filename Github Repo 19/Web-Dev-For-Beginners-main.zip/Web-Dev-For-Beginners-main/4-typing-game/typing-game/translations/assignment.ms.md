# Buat permainan papan kekunci baharu

## Arahan

Buat permainan kecil yang menggunakan acara papan kekunci untuk melakukan tugas. Ini boleh menjadi jenis permainan menaip yang berbeza, atau permainan jenis seni yang melukis piksel ke layar pada penekanan tombol. Dapatkan kreatif!

## Rubrik

| Kriteria | Contoh                | Mencukupi                 | Usaha Lagi |
| -------- | ------------------------ | ------------------------ | ----------------- |
|          | Permainan penuh dipersembahkan | Permainan ini sangat minimum | Permainan ini mempunyai pepijat |
