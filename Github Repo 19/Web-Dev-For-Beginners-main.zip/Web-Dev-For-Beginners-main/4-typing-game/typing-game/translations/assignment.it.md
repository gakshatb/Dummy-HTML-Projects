# Crearere un nuovo gioco con la tastiera

## Istruzioni

Creare un piccolo gioco che utilizzi gli eventi della tastiera per svolgere le attività. Può essere un tipo diverso di gioco di digitazione o un gioco di tipo artistico che disegna i pixel sullo schermo premendo i tasti. Si dia sfogo alla propria creatività!

## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | ------------------------ | ------------------------ | ----------------- |
|          | Viene presentato un gioco completo | Il gioco è molto minimale | Il gioco ha dei bug |
