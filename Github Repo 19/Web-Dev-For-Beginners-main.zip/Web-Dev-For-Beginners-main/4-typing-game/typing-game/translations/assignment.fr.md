# Créer un nouveau jeu de clavier

## Instructions

Créez un petit jeu qui utilise des événements de clavier pour effectuer des tâches. Il peut s'agir d'un autre type de jeu de dactylographie ou d'un jeu de type artistique qui peint des pixels à l'écran lors de frappes au clavier. Faites preuve de créativité!

## Rubrique

| Critères | Exemplaire                | Adéquat                 | Besoin d'amélioration |
| -------- | ------------------------ | ------------------------ | ----------------- |
|          | Un jeu complet est présenté | Le jeu est très minime | Le jeu a des bugs |
