# Create a new keyboard game

## Instructions

Create a small game that uses keyboard events to do tasks. It may be a different kind of typing game, or an art type game that paints pixels to the screen on keystrokes. Get creative!

## Rubric

| Criteria | Exemplary                | Adequate                 | Needs Improvement |
| -------- | ------------------------ | ------------------------ | ----------------- |
|          | A full game is presented | The game is very minimal | The game has bugs |
|          |                          |                          |                   |
