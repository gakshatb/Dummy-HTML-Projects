# Funksiyalarla Əylən

## Təlimatlar

Fərqli funksiyalar yaradın, həm nəyisə qaytaran funksiyalar, həm də heç nə qaytarmayan funksiyalar.

Defolt dəyərləri olan parametrlər və parametrlərin qarışığı olan bir funksiya yarada bildiyinizə baxın.

## Rubrika

| Meyarlar | Nümunəvi | Müvafiq | Təkmilləşdirmə Ehtiyacı var |
| -------- | ------------------------------------------------- ----------------------------------- | ------------------------------------------------- -------------- | ----------------- |
| | Həll müxtəlif parametrlərə malik iki və ya daha çox yaxşı işləyən funksiya ilə təklif olunur | İşçi həll bir funksiya və bir neçə parametr ilə təklif olunur | Həlldə səhvlər var |
