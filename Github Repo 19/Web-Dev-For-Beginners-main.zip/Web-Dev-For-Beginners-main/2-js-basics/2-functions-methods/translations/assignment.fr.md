# Du fun avec les fonctions

## Instructions

Créez différentes fonctions, à la fois des fonctions qui renvoient quelque chose et des fonctions qui ne renvoient rien.

Voyez si vous pouvez créer une fonction qui a un mélange de paramètres et de paramètres avec des valeurs par défaut.

## Rubrique

| Critères | Exemplaire | Adéquat | Besoin d'amélioration |
| -------- | -------------------------------------------------------------------------------------- | ---------------------------------------------------------------- | ----------------- |
| | La solution est proposée avec deux ou plusieurs fonctions performantes avec divers paramètres | La solution de travail est offerte avec une fonction et peu de paramètres | La solution a des bugs |
