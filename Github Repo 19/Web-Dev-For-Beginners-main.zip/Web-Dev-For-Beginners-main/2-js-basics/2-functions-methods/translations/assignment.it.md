# Divertimento con le funzioni

## Istruzioni

Creare diverse funzioni, sia funzioni che restituiscono qualcosa che funzioni che non restituiscono nulla.

Provare a creare una funzione che abbia un mix di parametri e parametri con valori predefiniti.

## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | -------------------------------------------------------------------------------------- | ---------------------------------------------------------------- | ----------------- |
|          | La soluzione è offerta con due o più funzioni con buone prestazioni con diversi parametri | La soluzione funzionante è offerta con una funzione e pochi parametri | La soluzione ha bug |