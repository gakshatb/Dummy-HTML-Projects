# Einführung in JavaScript

JavaScript ist die Sprache des Webs. In diesen vier Lektionen lernen Sie die Grundlagen.

### Themen

1. [Variablen und Datentypen](../1-data-types/translations/README.de.md)
2. [Funktionen und Methoden](../2-functions-methods/translations/README.de.md)
3. [Entscheidungen mit JavaScript treffen](../3-making-decisions/translations/README.de.md)
4. [Arrays und Loops](../4-arrays-loops/translations/README.de.md)

### Credits

Diese Lektionen wurden mit ♥ ️von [Jasmine Greenaway](https://twitter.com/paladique), [Christopher Harrison](https://twitter.com/geektrainer) und [Chris Noring](https://twitter.com/chris_noring) erstellt.
