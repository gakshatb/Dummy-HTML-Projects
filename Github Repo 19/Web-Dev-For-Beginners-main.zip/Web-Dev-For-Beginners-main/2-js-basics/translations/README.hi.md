# जावास्क्रिप्ट का परिचय

जावास्क्रिप्ट वेब की भाषा है। इन चार पाठों में, आप इसकी मूल बातें जानेंगे.

### विषय

1. [वेरिएबल्स और डेटा प्रकार](../1-data-types/translations/README.hi.md) 
2. [फंक्शंस और मेथड्स](../2-functions-methods/translations/README.hi.md)
3. [जावास्क्रिप्ट के साथ निर्णय करना](../3-making-decisions/translations/README.hi.md)
4. [अर्रेंज और लूप्स ](../4-arrays-loops/translations/README.hi.md)

### आभार सूची

ये पाठ ♥ से [Jasmine Greenaway](https://twitter.com/paladique), [Christopher Harrison](https://twitter.com/geektrainer) और [Chris Noring](https://twitter.com/chris_noring) द्वारा लिखे गए है
