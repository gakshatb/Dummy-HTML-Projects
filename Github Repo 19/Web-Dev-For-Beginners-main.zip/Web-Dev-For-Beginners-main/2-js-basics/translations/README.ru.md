# Введение в JavaScript

JavaScript это язык веб-программирования. В этих четырёх уроках вы изучите его основы.

### Уроки

1. [Переменные и типы данных](../1-data-types/README.md)
2. [Функции и методы](../2-functions-methods/README.md)
3. [Принятие решений с помощью JavaScript](../3-making-decisions/README.md)
4. [Массивы и циклы](../4-arrays-loops/README.md)

### Благодарность

Эти уроки были ♥️ созданы [Жасмин Гринуэй](https://twitter.com/paladique), [Кристофером Харрисоном](https://twitter.com/geektrainer) и [Крисом Норингом](https://twitter.com/chris_noring).
