# Вступ до JavaScript

JavaScript — це мова Інтернету. На цих чотирьох уроках ви дізнаєтеся його основи.

### Теми

1. [Змінні та типи данних](../1-data-types/README.md)
2. [Функції та Методи](../2-functions-methods/README.md)
3. [Прийняття рішень в JavaScript](../3-making-decisions/README.md)
4. [Масиви та Цикли](../4-arrays-loops/README.md)

### Титри

Ці уроки були написані з ♥️ від [Jasmine Greenaway](https://twitter.com/paladique), [Christopher Harrison](https://twitter.com/geektrainer) та [Chris Noring](https://twitter.com/chris_noring)