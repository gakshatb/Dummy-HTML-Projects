# Məlumat növləri üzrə məşqlər

## Təlimatlar

Təsəvvür edin ki, bir alış-veriş səbəti düzəldin. Alış-veriş təcrübənizi tamamlamaq üçün lazım olan məlumat növləri haqqında bəzi sənədləri yazın. Seçimlərinizə necə gəldiniz?

## Ünvan kitabçası

Meyarlar | Əla | adekvat | Təkmilləşdirmələr lazımdır
  --- | --- | --- | - |
  || Altı məlumat növü onların istifadəsini sənədləşdirərək ətraflı şəkildə sadalanır və araşdırılır | Dörd növ məlumat tədqiq edilir | İki növ məlumat tədqiq edilir |