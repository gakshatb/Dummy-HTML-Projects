# Prática de Tipos de Dados

## Instruções

Imagine que você está construindo um carrinho de compras. Escreva alguma documentação sobre os tipos de dados de que você precisa para completar sua experiência de compra. Como você fez suas escolhas?

## Rubrica

Critérios | Exemplar | Adequado | Precisa de melhorias
--- | --- | --- | - |
|| Os seis tipos de dados são listados e explorados em detalhes, documentando seu uso | Quatro tipos de dados são explorados | Dois tipos de dados são explorados |