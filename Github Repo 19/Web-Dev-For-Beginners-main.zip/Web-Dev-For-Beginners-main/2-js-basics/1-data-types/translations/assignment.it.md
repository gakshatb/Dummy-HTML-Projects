# Esercizi sui Tipi di Dato

## Istruzioni

Si immagini di costruire un carrello della spesa. Si scriva della documentazione sui tipi di dati necessari per completare la propria esperienza di acquisto. Come si è pervenuti alle proprie scelte?

## Rubrica

Criteri | Ottimo | Adeguato | Necessari miglioramenti
 --- | --- | --- | - |
 || I sei tipi di dato sono elencati ed esplorati in dettaglio, documentando il loro utilizzo | Vengono esplorati quattro tipi di dati | Vengono esplorati due tipi di dati |