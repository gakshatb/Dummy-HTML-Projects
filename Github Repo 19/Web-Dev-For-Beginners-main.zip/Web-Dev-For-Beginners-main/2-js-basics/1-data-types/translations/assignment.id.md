# Praktek Tipe Data

## Instruksi

Bayangkan Anda sedang membuat keranjang belanja. Tulislah beberapa dokumentasi tentang tipe data yang Anda perlukan untuk melengkapi pengalaman berbelanja Anda. Bagaimana Anda sampai pada pilihan Anda?

## Rubrik

| Kriteria | Contoh                                                                                 | Memenuhi Syarat              | Perlu Perbaikan            |
|----------|----------------------------------------------------------------------------------------|------------------------------|----------------------------|
|          | Enam tipe data didaftar dan dieksplorasi secara rinci, mendokumentasikan penggunaannya | Empat tipe data dieksplorasi | Dua tipe data dieksplorasi |
