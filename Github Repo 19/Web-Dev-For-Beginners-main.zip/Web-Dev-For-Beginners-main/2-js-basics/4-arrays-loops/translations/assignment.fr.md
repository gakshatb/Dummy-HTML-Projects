# Boucler un tableau

## Instructions

Créez un programme qui liste chaque 3ème nombre entre 1 et 20 et l'affiche sur la console.

> CONSEIL : utilisez une boucle for et modifiez l'expression d'itération

## Rubrique

| Critères | Exemplaire | Adéquat | Besoin d'amélioration |
| -------- | ---------------------------------------- | ------------------------ | ------------------------------ |
| | Le programme s'exécute correctement et est commenté | Le programme n'est pas commenté | Le programme est incomplet ou bogué |