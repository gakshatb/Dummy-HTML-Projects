# Loop an Array

## Arahan 

Buat program yang menyenaraikan setiap nombor ke-3 antara 1-20 dan mencetaknya ke konsol.

> TIP: gunakan for-loop dan ubah ekspresi iterasi

## Rubrik

| Kriteria | Contoh                              | Mencukupi                | Usaha Lagi             |
| -------- | --------------------------------------- | ------------------------ | ------------------------------ |
|          | Program berjalan dengan betul dan dikomentari | Program tidak dikomentari | Program tidak lengkap atau kereta |