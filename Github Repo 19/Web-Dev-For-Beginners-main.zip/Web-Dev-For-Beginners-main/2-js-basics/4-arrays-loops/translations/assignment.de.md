# Schleife ein Array

## Anleitung

Erstellen Sie ein Programm, das jede dritte Zahl zwischen 1 und 20 auflistet und auf der Konsole druckt.

> TIPP: Verwenden Sie eine for-Schleife und ändern Sie den Iterationsausdruck

## Rubrik

| Kriterien | Vorbildlich | Angemessen | Verbesserungsbedarf |
| -------- | --------------------------------------- | ------------------------ | ------------------------------ |
| | Programm läuft korrekt und ist kommentiert | Programm ist nicht kommentiert | Programm ist unvollständig oder fehlerhaft
