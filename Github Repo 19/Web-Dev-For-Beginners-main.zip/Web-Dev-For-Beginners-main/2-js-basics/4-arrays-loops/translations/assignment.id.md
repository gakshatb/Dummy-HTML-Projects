# Loop sebuah Array

## Instruksi

Buat program yang mencantumkan setiap nomor ke-3 antara 1-20 dan mencetaknya ke konsol.

> TIPS: gunakan for-loop dan ubah ekspresi iterasi

## Rubric

| Kriteria | Contoh                                            | Memenuhi                      | Perlu Perbaikan                       |
| -------- | ------------------------------------------------- | ----------------------------- | ------------------------------------- |
|          | Program berjalan dengan benar dan diberi komentar | Program tidak diberi komentar | Program tidak lengkap atau bermasalah |
