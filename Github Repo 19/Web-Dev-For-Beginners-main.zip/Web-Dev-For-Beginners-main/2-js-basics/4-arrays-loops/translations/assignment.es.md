# Hacer bucle en una matriz

## Instrucciones

Cree un programa que enumere cada tercer número entre 1 y 20 e imprimalo en la consola.

> SUGERENCIA: use un bucle for y modifique la expresión-iteración

## Rúbrica

| Criterios | Ejemplar | Adecuado | Necesita mejorar |
| -------- | --------------------------------------- | ------------------------ | ------------------------------ |
| | El programa se ejecuta correctamente y está comentado | Programa no comentado | El programa está incompleto o con errores |
