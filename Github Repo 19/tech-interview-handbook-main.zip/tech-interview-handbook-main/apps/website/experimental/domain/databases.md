# Databases

## General

- How should you store passwords in a database?
  - http://www.geeksforgeeks.org/store-password-database/
  - https://nakedsecurity.sophos.com/2013/11/20/serious-security-how-to-store-your-users-passwords-safely/
