- [ ] introduction.md
- [x] array.md
- [x] string.md
- [x] sorting-searching.md
- [x] recursion.md
- [x] hash-table.md
- [x] linked-list.md
- [x] stack.md
- [x] queue.md
- [x] matrix.md
- [x] graph.md
- [x] interval.md
- [x] tree.md
- [x] heap.md
- [x] trie.md
- [x] geometry.md
- [x] math.md
- [x] dynamic-programming.md
- [x] binary.md
<!-- - [ ] oop.md -->

## Introduction

TODO

## Learning resources

TODO

## Implementations

| Language   | API  |
| ---------- | ---- |
| C++        | []() |
| Java       | []() |
| Python     | []() |
| JavaScript | []() |

## Time complexity

TODO

| Operation | Big-O | Note |
| --------- | ----- | ---- |
| Access    | O(n)  |      |
| Search    | O(n)  |      |
| Insert    | O(1)  |      |
| Remove    | O(1)  |      |

## Things to look out for during interviews

TODO

## Corner cases

TODO

## Techniques

TODO

## Essential questions

_These are essential questions to practice if you're studying for this topic._

TODO

## Recommended practice questions

_These are recommended questions to practice after you have studied for the topic and have practiced the essential questions._

TODO
