import 'tailwindcss/tailwind.css';
import '@tih/ui/dist/styles.css';

export const parameters = {
  controls: { expanded: true },
};
