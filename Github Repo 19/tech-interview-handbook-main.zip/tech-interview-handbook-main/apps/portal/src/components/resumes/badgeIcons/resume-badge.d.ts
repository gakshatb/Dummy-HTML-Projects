export type ResumeBadgeProps = Readonly<{
  className: string;
}>;
