-- AlterTable
ALTER TABLE "ResumesResume" ALTER COLUMN "locationId" DROP DEFAULT;
