-- AlterTable
ALTER TABLE "OffersExperience" ADD COLUMN     "location" TEXT;
