-- AlterTable
ALTER TABLE "Country" ADD COLUMN     "ranking" INTEGER DEFAULT 0;
