-- AlterTable
ALTER TABLE "City" ADD COLUMN     "ranking" INTEGER DEFAULT 0;

-- AlterTable
ALTER TABLE "Company" ADD COLUMN     "ranking" INTEGER DEFAULT 0;
