-- AlterTable
ALTER TABLE "ResumesResume" ADD COLUMN     "isResolved" BOOLEAN NOT NULL DEFAULT false;
