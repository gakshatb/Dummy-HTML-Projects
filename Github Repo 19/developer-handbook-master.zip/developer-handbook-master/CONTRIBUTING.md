We are very open to contributions to extend or change the requirements based on your gut and experience. 
To contribute you can use a pull request which will be later validated by our technical team and added to the main docs.

If you will spot any issues please add them in the Issues section.
