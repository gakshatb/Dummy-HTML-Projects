# JavaScript Questions

Moved to [new location](https://www.frontendinterviewhandbook.com/javascript-questions/).
