# CSS Questions

Moved to [new location](https://www.frontendinterviewhandbook.com/css-questions/).
